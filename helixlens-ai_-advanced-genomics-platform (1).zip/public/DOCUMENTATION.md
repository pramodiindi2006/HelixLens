# AI-Powered CRISPR Gene-Editing Simulation
*Theoretical Framework & Technical Documentation*
*Hackathon Edition | Biotech + AI | Full Simulation*

---

## Document Overview
1. Introduction to Gene Editing & CRISPR
2. Biological Background
3. CRISPR-Cas9 Mechanism
4. DNA Repair Pathways
5. Gene-Specific Disease Strategies
6. Simulation Logic & Architecture
7. Protein Impact Analysis
8. Outcome Prediction System
9. Off-Target Effects
10. AI Integration
11. Comparison with Existing Tools
12. Applications
13. Limitations & Ethics
14. Conclusion & Future Scope

---

## SECTION 01: Introduction to Gene Editing & CRISPR

### 1.1 What Is Gene Editing?
Gene editing is a set of molecular biology techniques that allow scientists to precisely alter, add, delete, or replace DNA sequences within a living organism's genome. Think of the genome as an enormous instruction manual for life — written in a four-letter chemical alphabet (A, T, C, G) — and gene editing as the ability to find a specific sentence in that manual and rewrite it with surgical precision. This capability unlocks the potential to correct the genetic 'typos' that cause inherited diseases, enhance beneficial traits, and study the function of individual genes.

### 1.2 CRISPR-Cas9: The Molecular Scissors
CRISPR (Clustered Regularly Interspaced Short Palindromic Repeats) combined with the Cas9 protein represents the most revolutionary gene-editing technology ever developed. Originally discovered as part of the bacterial immune system — bacteria use CRISPR sequences to 'remember' viruses they have encountered — scientists repurposed the system as a programmable DNA-cutting tool in 2012. This discovery earned Jennifer Doudna and Emmanuelle Charpentier the 2020 Nobel Prize in Chemistry.

The brilliance of CRISPR-Cas9 lies in its simplicity: a short RNA molecule (guide RNA) directs the Cas9 protein — a molecular scissors — to an exact DNA location, where it makes a precise double-strand cut. Previous editing tools (zinc-finger nucleases, TALENs) required custom protein engineering for every new target; CRISPR simply needs a new 20-nucleotide RNA sequence, making it dramatically faster and cheaper.

### 1.3 Why Gene Editing Matters in Modern Medicine
Over 10,000 known human diseases are caused by single-gene mutations. Traditional treatments manage symptoms but rarely address root causes. Gene editing offers the prospect of one-time curative therapies that correct the underlying genetic defect. Clinical milestones already achieved include:
* FDA-approved CRISPR therapy (Casgevy, 2023) for Sickle Cell Disease and Beta-Thalassemia
* Multiple Phase I/II clinical trials for cancers, HIV, and metabolic disorders
* Ex vivo cell therapies where patient cells are edited and reinfused
* In vivo editing using lipid nanoparticles for liver diseases (e.g., TTR amyloidosis)

### 1.4 Target Diseases in This Simulation
| Disease | Gene | Mutation Type | Global Prevalence |
|---|---|---|---|
| Sickle Cell Disease | HBB | Point mutation (GAG→GTG) | ~300,000 births/year |
| Cystic Fibrosis | CFTR | 3bp deletion (∆F508) | ~70,000 people worldwide |
| Huntington's Disease | HTT | CAG trinucleotide repeat | ~1 in 10,000 people |

---

## SECTION 02: Biological Background

### 2.1 The Central Dogma of Molecular Biology
The central dogma describes the fundamental flow of genetic information in living organisms. It establishes that information travels in one direction: from DNA to RNA to Protein. This is the molecular 'pipeline' that all gene editing ultimately targets.

* **DNA (Deoxyribonucleic Acid — The Blueprint):** The master copy of genetic information stored in the nucleus, organized into 23 pairs of chromosomes. DNA is double-stranded, with each strand composed of nucleotide bases (Adenine, Thymine, Cytosine, Guanine) paired by hydrogen bonds.
* **RNA (Transcription — Copying the Message):** During transcription, RNA polymerase reads the DNA template and synthesizes messenger RNA (mRNA). The mRNA is a working copy that leaves the nucleus. Unlike DNA, RNA is single-stranded and uses Uracil instead of Thymine.
* **Protein (Translation — Building the Machine):** Ribosomes read the mRNA in three-nucleotide units called codons. Each codon specifies one of 20 amino acids. Amino acids are chained together to form a polypeptide, which folds into a functional protein. A single mutation in DNA can cascade to a faulty protein.

### 2.2 Gene Mutations — Types and Consequences
Mutations are changes in the DNA sequence. Not all mutations are harmful — many are neutral — but certain mutations disrupt protein structure and function, causing disease.

| Mutation Type | Description | Example |
|---|---|---|
| Substitution | One nucleotide replaced by another. Can be silent, missense, or nonsense. | HBB: GAG → GTG causes Glu → Val substitution (SCD) |
| Insertion | One or more nucleotides added into the sequence. | HTT: CAG repeat insertion (36+ copies = disease) |
| Deletion | One or more nucleotides removed from the sequence. | CFTR: 3bp deletion removes phenylalanine at position 508 |

### 2.3 Frameshift vs. In-Frame Mutations

**Frameshift Mutations:**
A frameshift mutation results from inserting or deleting a number of nucleotides that is NOT a multiple of 3. Since codons are read in triplets, this shifts the entire reading frame downstream of the mutation.
* All downstream codons are altered
* Usually leads to premature stop codons
* Produces a truncated, non-functional protein
* Example: Insert 1bp → reading frame shifts → garbage sequence

**In-Frame Mutations:**
An in-frame mutation involves insertion or deletion of nucleotides in multiples of 3. The reading frame is maintained, so the protein is mostly intact.
* Only the inserted/deleted amino acids differ
* Protein length changes minimally
* May retain partial or full function
* Example: Delete 3bp (∆F508) → one amino acid missing but frame preserved

---

## SECTION 03: CRISPR-Cas9 Mechanism

The CRISPR-Cas9 system operates through a highly precise, programmable mechanism involving two key molecular components: a guide RNA that provides targeting specificity, and the Cas9 endonuclease that performs the actual DNA cutting. Understanding each step is essential to understanding how editing works — and why precision matters.

1. **Guide RNA (gRNA) Design:** The guide RNA is a synthetic ~100-nucleotide RNA molecule comprising two functional regions: a 20-nucleotide spacer sequence (complementary to the target DNA) and a scaffold sequence that recruits the Cas9 protein. The spacer is the 'address label' — it must perfectly match the genomic target for efficient editing. Poor gRNA design increases off-target cutting risk.
2. **Target DNA Recognition:** The Cas9-gRNA complex scans the genome by sliding along DNA. When the gRNA spacer finds complementary DNA, it base-pairs in an R-loop configuration. This is highly specific — even a single mismatch in the seed region (positions 1–12) can abolish activity, providing a natural specificity filter.
3. **PAM Sequence Requirement:** Before Cas9 can cut, it must find a Protospacer Adjacent Motif (PAM) sequence — specifically 5'-NGG-3' — immediately downstream (3') of the target on the non-template strand. This is a critical safety lock: without the PAM, Cas9 will NOT cut. The PAM requirement limits targetable sites to ~1 per 8bp in the human genome statistically.
4. **Cas9 Conformational Activation:** PAM recognition triggers a conformational change in Cas9. The REC lobe clamps down on the DNA, while the HNH and RuvC nuclease domains become positioned to cleave the complementary and non-complementary strands respectively. This two-domain architecture ensures both strands are cut simultaneously.
5. **Double-Strand Break (DSB) Formation:** Cas9 cleaves both DNA strands 3 base pairs upstream of the PAM sequence, generating a blunt-ended double-strand break. This DSB is the critical event that triggers the cell's DNA repair machinery. The two repair pathways — NHEJ and HDR — then compete to resolve this break, with very different outcomes for the gene.

**KEY CONCEPT: Why the PAM Sequence Matters**
The NGG PAM requirement serves two purposes: (1) Biological — it prevents Cas9 from cutting its own CRISPR array in bacteria (which lacks PAMs); (2) Practical — it constrains targetable sites. For human genome editing, a 20nt gRNA + NGG PAM provides ~1,000-fold specificity beyond gRNA alone. Engineered Cas9 variants (SpRY, Cas12a) use different PAMs to expand targeting range.

---

## SECTION 04: DNA Repair Pathways

After Cas9 creates a double-strand break, the cell's endogenous DNA repair machinery must fix it. There are two primary pathways, and which one is used determines the editing outcome. The cell cannot be instructed which pathway to use — this is one of the fundamental challenges of CRISPR editing.

### NHEJ Pathway (Non-Homologous End Joining)
NHEJ is the cell's default, fast-acting repair mechanism. It directly ligates the broken ends without requiring a template sequence. Because it operates by 'stitching' ends together rather than reading a template, it is inherently error-prone.
* **How NHEJ Works:** Ku proteins recognize and bind broken DNA ends → DNA-PKcs assembles repair complex → Artemis trims incompatible overhangs → DNA ligase IV seals the break.
* **Outcomes:** Random insertions/deletions (indels) of 1-50+ nucleotides. If not a multiple of 3: frameshift → gene knockout. If multiple of 3: in-frame indel → possible partial function.
* **Efficiency:** 70-90% of repair events. Used for gene disruption (loss-of-function) experiments and to eliminate dominant-negative mutations.

### HDR Pathway (Homology-Directed Repair)
HDR uses a template sequence with homology to the cut site to achieve precise, error-free correction. This pathway is only active during S and G2 phases of the cell cycle, limiting its efficiency.
* **How HDR Works:** Broken ends resected to generate 3' overhangs → RPA stabilizes ssDNA → RAD51 loads and searches for homology → Strand invasion into repair template occurs → Template-guided DNA synthesis corrects sequence.
* **Outcomes:** Precise sequence correction (if corrective template provided). Knock-in of new sequences or tags. Perfect gene restoration possible.
* **Efficiency:** 1-10% in most cell types. Improves with cell cycle synchronization, increased template concentration.

**Simulation Implication: Modeling Repair Pathway Competition**
In our simulation, after a DSB is generated, the system probabilistically assigns the repair outcome based on configurable parameters. Default probabilities: NHEJ: 85% (of which ~65% cause frameshift, ~35% cause in-frame indel) | HDR: 15% (near-perfect correction when template is provided). These values are adjustable to model different cell types, cell cycle states, and experimental conditions.

---

## SECTION 05: Gene-Specific Disease Strategies

### 5.1 HBB Gene — Sickle Cell Disease
SCD is caused by an A → T transversion in exon 1 of HBB, converting glutamic acid to valine at position 6 (HbS). Deoxygenated HbS polymerizes, causing sickling, anemia, and organ damage.
* **CRISPR Correction Strategy (HDR):** Design gRNA targeting codon 6, provide HDR template with wild-type GAG sequence to restore normal HbA.
* **Alternative Strategy (NHEJ):** Disrupt BCL11A enhancer to reawaken fetal hemoglobin (HBG1/HBG2). This is the mechanism used in the FDA-approved Casgevy therapy.

### 5.2 CFTR Gene — Cystic Fibrosis
CF is caused by mutations in the CFTR chloride channel, most commonly a 3bp in-frame deletion (∆F508) that causes misfolding and degradation of the protein, leading to thick mucus in lungs.
* **CRISPR Correction Strategy (HDR):** HDR-mediated precise re-insertion of the missing TTT (phenylalanine) codon to restore protein folding. Lung delivery remains challenging.

### 5.3 HTT Gene — Huntington's Disease
Autosomal dominant disorder caused by a CAG trinucleotide repeat expansion (>36 repeats) in exon 1 of HTT, producing toxic aggregating mutant huntingtin (mHTT) protein.
* **Allele-Specific Knockout (NHEJ):** Target expanded CAG region with deletion-causing gRNA to disrupt mHTT expression (requires targeting allele-specific SNPs).
* **Repeat Contraction (HDR):** HDR with a template containing normal repeat numbers to precisely remove excess CAG repeats (very challenging technically).

---

## SECTION 06: Simulation Logic & Architecture

The core of this project is a computational simulation engine modeling the entire CRISPR pipeline:
1. **Input: DNA Sequence:** Validates raw DNA sequences or pre-loaded disease sequences.
2. **gRNA Targeting & Cut-Site Identification:** Scans for NGG PAM sites, extracts protospacers, scores candidates (efficiency, GC content, off-target potential), and marks cut site at -3 relative to PAM.
3. **Simulating NHEJ Repair:** Stochastically generates indels at the cut site using geometric distributions for insertions and long-tail for deletions. Runs N Monte Carlo simulations to report spectrum.
4. **Simulating HDR Repair:** Models template-directed repair when an HDR template is provided, restoring sequence based on configured success probabilities.
5. **Output: Edited DNA & Analysis:** Returns full edited sequence, sequence alignment, protein translation, and summary statistics.

**Technology Stack:**
* **Frontend:** React.js, Tailwind CSS, shadcn/ui.
* **In-Browser Bioinformatics:** Custom TS algorithms for sequence manipulation, alignment (Needleman-Wunsch), and probabilistic Monte Carlo outcomes without needing a python backend.
* **AI Layer:** Google Gemini API for natural language interpretation and "Co-Pilot" guidance.

---

## SECTION 07: Protein Impact Analysis

Gene editing is only meaningful if we understand changes to the resulting protein.
1. **DNA to Protein Pipeline:** Identify Open Reading Frame (ORF) → Codon-by-Codon Translation → Detect Frameshifts → Identify Premature Stop Codons → Protein Length Comparison.
2. **Functional Impact Prediction:**
   * Frameshift + premature stop (early) → Severe loss of function (Knockout/Null)
   * Frameshift + premature stop (late) → Partial function possible (Hypomorphic)
   * In-frame deletion (conserved domain) → Structural disruption (Loss of function)
   * HDR correction to wild-type → Full restoration (Curative)

---

## SECTION 08: Outcome Prediction System & Engine Mathematics

A key differentiator of this platform is the deterministic, high-performance outcome prediction system. Unlike generic randomizers, the engine utilizes linear biological models derived from predictive machine learning research (e.g., FORECasT, inDelphi) simplified for $O(1)$ real-time visualization.

### 8.1 Cas9 DNA Cleavage (Cutting Efficiency)
Cas9 binding and cleavage are highly dependent on guide RNA stability. Optimal GC content is typically 40-60%. Deviations reduce stability or increase secondary structures; mismatches decrease binding affinity.
*   **Theory:** Thermodynamic stability of the RNA-DNA heteroduplex.
*   **Formula:** $E = 0.7 - 0.4 \times \left| \frac{GC - 50}{50} \right| - 0.2 \times \text{OffTargetRisk}$
*   *(Note: Efficiency is clamped and strictly $0$ if the NGG PAM sequence is absent).*

### 8.2 Double-Strand Break (DSB) Repair Dynamics
After a DSB, the cell employs different repair mechanisms. In standard mammalian cells, non-homologous end joining (NHEJ) dominates across all cell cycle phases, while homology-directed repair (HDR) is restricted primarily to S/G2 phases.
*   **Theory:** Competing repair pathways based on cellular phase and repair complex kinetics.
*   **Pathways:** $P(NHEJ) = 0.95$, $P(HDR) = 0.05$.

### 8.3 Mutation-Level Outcomes (Indel Distribution)
Cas9 cleavage predominantly results in staggered cuts (producing 1bp overhangs) or small resections. The engine utilizes a rigorously fixed probability map reflecting real-world sequencing data of NHEJ repair:
*   **Distribution:** $+1\text{bp}$ (35%), $-1\text{bp}$ (30%), $-2\text{bp}$ (15%), $-3\text{bp}$ (10%), Others (10%).
*   **Frameshift Math ($n \not\equiv 0 \pmod 3$):** $P(\text{Frameshift}) = 0.35 + 0.30 + 0.15 + (0.10 \times 0.66) \approx 0.866$
*   **In-Frame Math ($n \equiv 0 \pmod 3$):** $P(\text{In-Frame}) = 0.10 + (0.10 \times 0.33) \approx 0.133$

### 8.4 Functional Protein Outcomes (Knockout Success)
Not all genomic frameshifts produce a complete functional knockout. A frameshift near the extreme C-terminus may leave the active site intact. The engine employs a "Disruption Factor" (0.9) representing the high probability (90%) of Nonsense-Mediated Decay (NMD) or complete structural collapse.
*   **Theory:** Functional biology vs. Genomic sequence.
*   **Formula:** $P(\text{Functional KO}) = E \times P(NHEJ) \times P(\text{Frameshift}) \times 0.9$

This tiered calculation explicitly guarantees that biological **Success Probability** is logically distinct from, and strictly less than or equal to, raw **Cutting Efficiency**.

---

## SECTION 09: Off-Target Effects

Off-target effects occur when Cas9 cuts unintended genomic locations with sequence similarity.
* **Risks:** Oncogenic risk (cutting tumor suppressors), Gene Function Disruption (essential gene knockout), Chromosomal rearrangements.
* **Simulation Prediction:** Implements computational off-target prediction returning Risk Levels based on mismatch counts (e.g. 0-1 mismatches = HIGH Risk / Redesign required; 4-5 mismatches = LOW Risk).

---

## SECTION 10: AI Integration — The Innovation Layer

The AI integration module (powered by Gemini) bridges the gap between raw computational outputs and human understanding:
1. **AI Copilot:** Generates plain-English summaries of simulation results.
2. **Natural Language Queries:** "What does a frameshift mean for my patient?"
3. **Automated Interpretation:** Flags concerning outcomes (low HDR, high off-target).
4. **Educational Mode:** "Explain this to me like I'm 15."
5. **gRNA Optimization:** Analyzes performance patterns and suggests modifications.

---

## SECTION 11-14: Comparisons, Applications & Ethics

* **Advantages over Existing Tools (Benchling, CHOPCHOP):** End-to-end pipeline with editing simulation, protein-level translation impact, visual+AI explanation, multi-disease modeling, and probabilistic outputs.
* **Applications:** Drug Discovery, Genetic Disease Research, Education & Training, Personalized Medicine.
* **Limitations:** Simulation ≠ Wet Lab. Biological complexity (chromatin, immune response) and cell-type specificity vary enormously.
* **Ethics:** Models somatic editing only. Germline editing strictly avoided. Dual-use restrictions apply to pathogens.
* **Future Scope:** ClinVar integration, Base Editing (CBE/ABE) simulation, 3D protein visualization, Multiplexed editing.

*The future of medicine will be written in the language of DNA. This platform gives everyone the ability to write intelligently, predict accurately, and understand deeply.*
