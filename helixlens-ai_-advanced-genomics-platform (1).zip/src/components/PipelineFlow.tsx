import React from 'react';
import { motion } from 'motion/react';
import { 
  Activity, Dna, Beaker, Zap, AlertTriangle, Microscope, 
  ChevronRight, ArrowRight
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface PipelineFlowProps {
  currentStep: number;
  steps: {
    title: string;
    description: string;
    icon: any;
    status: 'pending' | 'active' | 'complete';
  }[];
}

export const PipelineFlow: React.FC<PipelineFlowProps> = ({ steps }) => {
  return (
    <div className="w-full py-6 overflow-x-auto custom-scrollbar">
      <div className="flex items-center gap-4 min-w-max px-4">
        {steps.map((step, index) => (
          <React.Fragment key={index}>
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "flex flex-col items-center gap-2 w-32 text-center group",
                step.status === 'active' ? "opacity-100" : "opacity-40"
              )}
            >
              <div className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center transition-all duration-500",
                step.status === 'active' ? "bg-purple-500 text-white shadow-lg shadow-purple-500/40 scale-110" : 
                step.status === 'complete' ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40" :
                "bg-slate-800 text-slate-500 border border-slate-700"
              )}>
                <step.icon className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <p className={cn(
                  "text-[10px] font-bold uppercase tracking-tighter",
                  step.status === 'active' ? "text-white" : "text-slate-500"
                )}>
                  {step.title}
                </p>
                <p className="text-[8px] text-slate-600 leading-tight line-clamp-2 px-2">
                  {step.description}
                </p>
              </div>
            </motion.div>
            {index < steps.length - 1 && (
              <div className="flex items-center">
                <ArrowRight className={cn(
                  "w-4 h-4",
                  steps[index + 1].status !== 'pending' ? "text-emerald-500" : "text-slate-800"
                )} />
              </div>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};
