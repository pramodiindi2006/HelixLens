import React from 'react';
import { motion } from 'motion/react';
import { StoryStep } from '../types/bio';
import { 
  Dna, Search, Zap, Activity, ChevronRight, 
  CheckCircle2, Info
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface StoryModeProps {
  steps: StoryStep[];
  currentStep: number;
}

const IconMap: Record<string, any> = {
  Dna, Search, Zap, Activity
};

export const StoryMode: React.FC<StoryModeProps> = ({ steps, currentStep }) => {
  return (
    <div className="space-y-6 py-4">
      {steps.map((step, index) => {
        const Icon = IconMap[step.icon] || Info;
        const isActive = index === currentStep;
        const isComplete = index < currentStep;
        
        return (
          <motion.div 
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ 
              opacity: isActive || isComplete ? 1 : 0.3, 
              x: 0,
              scale: isActive ? 1.02 : 1
            }}
            className={cn(
              "relative pl-10 pb-8 last:pb-0 border-l-2 transition-all duration-500",
              isComplete ? "border-emerald-500" : isActive ? "border-purple-500" : "border-slate-800"
            )}
          >
            <div className={cn(
              "absolute -left-[17px] top-0 w-8 h-8 rounded-full flex items-center justify-center z-10 transition-all duration-500",
              isComplete ? "bg-emerald-500 text-white" : 
              isActive ? "bg-purple-500 text-white shadow-lg shadow-purple-500/40" : 
              "bg-slate-900 text-slate-600 border-2 border-slate-800"
            )}>
              {isComplete ? <CheckCircle2 className="w-5 h-5" /> : <Icon className="w-4 h-4" />}
            </div>
            
            <div className={cn(
              "p-4 rounded-xl border transition-all duration-500",
              isActive ? "bg-slate-800/50 border-purple-500/50 shadow-xl" : "bg-slate-900/30 border-slate-800"
            )}>
              <h3 className={cn(
                "text-sm font-bold mb-1 flex items-center gap-2",
                isActive ? "text-white" : isComplete ? "text-emerald-400" : "text-slate-500"
              )}>
                Step {index + 1}: {step.title}
                {isActive && (
                  <motion.span 
                    animate={{ opacity: [1, 0.5, 1] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                    className="w-2 h-2 rounded-full bg-purple-500"
                  />
                )}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {step.description}
              </p>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};
