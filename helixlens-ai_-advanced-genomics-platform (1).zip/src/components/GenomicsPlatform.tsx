import React, { useState, useMemo, useEffect } from 'react';
import { 
  Dna, 
  Users, 
  Zap, 
  ShieldAlert, 
  Microscope, 
  ChevronRight, 
  Activity, 
  Layout,
  FlaskConical,
  PieChart as PieChartIcon,
  Search,
  BookOpen,
  Info,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Target,
  BrainCircuit,
  Scaling,
  Stethoscope,
  Heart,
  FileText,
  Lock,
  Globe,
  RefreshCcw,
  AlertCircle,
  Loader2,
  CheckCircle2,
  Beaker
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GENE_DATASET, FamilyMember, GeneData, SimulationResult } from '../types/bio';
import { cn } from '@/lib/utils';
import { DNA3DViewer } from './DNA3DViewer';
import { PedigreeChart } from './PedigreeChart';
import { RiskDashboard } from './RiskDashboard';
import { Protein3DViewer } from './Protein3DViewer';
import { analyzeGeneticRisk } from '../lib/risk-engine';
import { designGRNAs, simulateEdit, compareProteins } from '../lib/bio-utils';
import { ScientificReport } from './ScientificReport';

export const GenomicsPlatform: React.FC = () => {
  const [geneLibrary, setGeneLibrary] = useState<GeneData[]>(GENE_DATASET);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'library' | 'risk' | 'crispr' | 'report'>('dashboard');
  const [selectedGene, setSelectedGene] = useState<GeneData>(geneLibrary[0]);
  const [showAddGene, setShowAddGene] = useState(false);
  const [newGene, setNewGene] = useState<Partial<GeneData>>({
    inheritance: 'Autosomal Dominant',
    penetrance: 1.0,
    sequence: '',
    domains: []
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [aiStatus, setAiStatus] = useState<{ active: boolean, engine: string }>({ active: true, engine: 'Loading...' });
  const [validationResult, setValidationResult] = useState<{
    errors: string[];
    explanation: string;
    score: number;
    correctedData: any;
  } | null>(null);

  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([
    { id: '1', name: 'You', relation: 'Self', sex: 'M', affected: false, carrier: true },
    { id: '2', name: 'Father', relation: 'Father', sex: 'M', affected: true, carrier: false },
    { id: '3', name: 'Mother', relation: 'Mother', sex: 'F', affected: false, carrier: true },
    { id: '4', name: 'Grandfather', relation: 'Paternal Grandfather', sex: 'M', affected: true, carrier: false },
  ]);

  const [simulation, setSimulation] = useState<SimulationResult | null>(null);
  const [selectedGuide, setSelectedGuide] = useState<any>(null);
  const [timelineStep, setTimelineStep] = useState(0);

  const riskAnalysis = useMemo(() => {
    return analyzeGeneticRisk(selectedGene, familyMembers);
  }, [selectedGene, familyMembers]);

  const guides = useMemo(() => {
    return designGRNAs(selectedGene.sequence);
  }, [selectedGene]);

  const runSimulation = (guide: any, type: any) => {
    const result = simulateEdit(selectedGene.sequence, guide, type, { 
      deletionSize: type === 'knockout' ? 1 : 0,
      substitutionBase: type === 'correction' ? (selectedGene.id === 'hbb' ? 'A' : 'G') : undefined
    }, [], selectedGene.id);
    setSimulation(result);
    setSelectedGuide(guide);
    setTimelineStep(1);
    
    // Auto progress animation steps
    setTimeout(() => setTimelineStep(2), 2000);
    setTimeout(() => setTimelineStep(3), 4000);
  };

  const proteinDiffs = useMemo(() => {
    if (!simulation) return [];
    return compareProteins(simulation.originalProtein, simulation.mutatedProtein, simulation.impact.includes('Frameshift'));
  }, [simulation]);

  const handleAddGene = () => {
    if (!newGene.name || !newGene.disease || !newGene.sequence) return;
    
    const geneDoc: GeneData = {
      id: newGene.name.toLowerCase().replace(/\s+/g, '-'),
      name: newGene.name.toUpperCase(),
      disease: newGene.disease,
      sequence: newGene.sequence.toUpperCase().replace(/[^ATCG]/g, ''),
      description: newGene.description || 'Custom added gene.',
      inheritance: newGene.inheritance as any || 'Autosomal Dominant',
      prevalence: newGene.prevalence || 'Unknown',
      penetrance: newGene.penetrance || 1.0,
      domains: newGene.domains || [],
      mutationType: newGene.mutationType,
      strategy: newGene.strategy,
      gcContent: newGene.gcContent,
      notes: newGene.notes
    };
    
    setGeneLibrary([geneDoc, ...geneLibrary]);
    setSelectedGene(geneDoc);
    setShowAddGene(false);
    setNewGene({ inheritance: 'Autosomal Dominant', penetrance: 1.0, sequence: '' });
  };

  useEffect(() => {
    fetch('/api/health')
      .then(r => r.json())
      .then(data => setAiStatus({ active: data.aiActive, engine: data.engine }))
      .catch(() => setAiStatus({ active: false, engine: 'Offline' }));
  }, []);

  const toggleMemberStatus = (id: string, field: 'affected' | 'carrier') => {
    setFamilyMembers(members => 
      members.map(m => {
        if (m.id === id) {
          const updated = { ...m, [field]: !m[field] };
          // If affected, must be carrier or expressed
          if (field === 'affected' && updated.affected) updated.carrier = false;
          if (field === 'carrier' && updated.carrier) updated.affected = false;
          return updated;
        }
        return m;
      })
    );
  };

  const generateGeneDetails = async (geneName: string, disease: string) => {
    if (!geneName || !disease) return;
    setIsGenerating(true);
    setValidationResult(null);
    try {
      const response = await fetch('/api/generate-gene-details', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          geneName: geneName, // Symbol
          disease: disease
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate details');
      }
      
      const data = await response.json();
      
      if (data.description === "Entry not found or genetically unrelated") {
         alert("Could not find a valid genomic profile for this gene-disease pair. Please check your spelling or try a different combination.");
         return;
      }
      
      setNewGene(prev => ({
        ...prev,
        sequence: data.sequence || prev.sequence,
        inheritance: data.inheritance || prev.inheritance,
        description: data.description || prev.description,
        penetrance: data.penetrance || prev.penetrance,
        prevalence: data.prevalence || prev.prevalence,
        domains: data.domains || prev.domains,
        mutationType: data.mutationType || prev.mutationType,
        strategy: data.strategy || prev.strategy,
        gcContent: data.gcContent || prev.gcContent,
        notes: data.notes || prev.notes
      }));
    } catch (e: any) {
      console.error(e);
      alert('AI Generation Error: ' + e.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const validateGeneEntry = async () => {
    if (!selectedGene) return;
    setIsValidating(true);
    try {
      const response = await fetch('/api/validate-genomics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          geneData: {
            name: selectedGene.name,
            disease: selectedGene.disease,
            sequence: selectedGene.sequence,
            inheritance: selectedGene.inheritance,
            penetrance: selectedGene.penetrance,
            prevalence: selectedGene.prevalence,
            domains: selectedGene.domains
          } 
        })
      });
      const data = await response.json();
      setValidationResult({
        errors: data.errors_found,
        explanation: data.biological_explanation,
        score: data.confidence_score,
        correctedData: data.corrected_data
      });
    } catch (e) {
      console.error(e);
    } finally {
      setIsValidating(false);
    }
  };

  const applyCorrections = () => {
    if (!validationResult) return;
    const { correctedData } = validationResult;
    
    setSelectedGene(prev => ({
      ...prev,
      name: (correctedData.gene_symbol || prev.name).toUpperCase(),
      disease: correctedData.disease_name || prev.disease,
      sequence: correctedData.dna_sequence || prev.sequence,
      inheritance: correctedData.inheritance as any || prev.inheritance,
      penetrance: correctedData.penetrance || prev.penetrance,
      prevalence: correctedData.prevalence || prev.prevalence,
      domains: correctedData.protein_domains || prev.domains
    }));
    setValidationResult(null);
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      // Auto-trigger if we have enough info but no sequence yet, to save user from clicking
      if (showAddGene && newGene.name && newGene.disease && newGene.name.length > 2 && newGene.disease.length > 3 && !newGene.sequence && (!newGene.domains || newGene.domains.length === 0) && !isGenerating) {
        generateGeneDetails(newGene.name, newGene.disease);
      }
    }, 3000);
    return () => clearTimeout(timer);
  }, [newGene.name, newGene.disease, showAddGene, newGene.sequence, newGene.domains, isGenerating]);

  const menuItems = [
    { id: 'library', label: 'Gene Library', icon: BookOpen },
    { id: 'risk', label: 'Risk Analysis', icon: PieChartIcon },
    { id: 'crispr', label: 'CRISPR Lab', icon: Zap },
    { id: 'report', label: 'Student Case Report', icon: FileText },
  ];

  return (
    <div className="flex h-screen bg-slate-900 text-slate-200 overflow-hidden font-sans">
      {/* Sidebar */}
      <aside className="w-64 border-r border-slate-800/50 flex flex-col p-6 bg-slate-900/40 backdrop-blur-xl">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-9 h-9 bg-white text-black rounded-lg flex items-center justify-center font-black text-xl shadow-2xl">
            H
          </div>
          <div>
            <h1 className="text-sm font-black uppercase tracking-[0.2em] text-white leading-none">HelixLens</h1>
            <span className="text-[10px] font-medium text-slate-500 uppercase tracking-widest mt-1 block">Education Platform</span>
          </div>
        </div>

        <nav className="space-y-1.5 mb-auto">
          {menuItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-semibold transition-all ${
                activeTab === item.id 
                  ? 'bg-white text-black shadow-lg shadow-white/5' 
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className={`w-4 h-4 ${activeTab === item.id ? 'stroke-[2.5px]' : 'stroke-[1.5px]'}`} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="mt-8 p-5 bg-slate-900/50 rounded-2xl border border-slate-800/50 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent pointer-events-none" />
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-3">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
              <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Protocol 404</span>
            </div>
            <p className="text-[10px] text-slate-500 leading-relaxed font-medium">
              Simulation environment active. Learning progress is tracked for your educational profile.
            </p>
            <button className="mt-4 flex items-center gap-2 text-[10px] font-bold text-white uppercase tracking-wider group-hover:gap-3 transition-all">
              Documentation <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Header - High-Fidelity Architectural Look */}
        <header className="h-24 border-b border-white/5 flex items-center justify-between px-12 bg-slate-900/50 relative z-20 shrink-0 shadow-lg">
          <div className="flex items-center gap-12">
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-slate-600 uppercase tracking-[0.4em] mb-2">Academic Case Study</span>
              <div className="flex items-center gap-4">
                <span className="text-2xl font-black text-white tracking-tighter uppercase">{selectedGene.name}</span>
                <div className="px-3 py-1 rounded-lg border border-white/10 bg-white/5 text-[9px] font-black text-slate-400 tracking-[0.2em] flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
                  ID-REF: {selectedGene.id.toUpperCase()}
                </div>
              </div>
            </div>
            
            <div className="h-10 w-[1px] bg-white/5" />

            <div className="flex items-center gap-10">
              <div className="flex flex-col">
                <span className="text-[9px] font-black text-slate-700 uppercase tracking-widest mb-1">Telemetry</span>
                <div className="flex items-center gap-2.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[11px] font-black text-white uppercase tracking-widest">Live Link 1.0</span>
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-[9px] font-black text-slate-700 uppercase tracking-widest mb-1">Cortex Node</span>
                <span className="text-[11px] font-black text-slate-300 uppercase tracking-tight whitespace-nowrap">{aiStatus.engine}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-8">
             <div className="flex -space-x-3">
               {[1,2,3].map(i => (
                 <div key={i} className="w-9 h-9 rounded-full border-2 border-slate-950 bg-slate-900 flex items-center justify-center text-[10px] font-black text-slate-500 hover:scale-110 transition-transform cursor-pointer relative z-[30-i]">
                    <Users className="w-4 h-4" />
                 </div>
               ))}
             </div>
             <button title="Refresh System" className="w-12 h-12 rounded-2xl border border-white/5 bg-white/5 flex items-center justify-center text-slate-500 hover:text-white hover:bg-white/10 transition-all shadow-2xl">
               <RefreshCcw className="w-5 h-5" />
             </button>
          </div>
        </header>

        {/* Navigation Bar */}
        <div className="h-14 border-b border-white/5 bg-slate-900/30 flex items-center px-12 gap-10 shrink-0">
          {[
            { id: 'dashboard', label: 'System Overview', icon: Layout },
            { id: 'library', label: 'Genomic Catalog', icon: Dna },
            { id: 'risk', label: 'Risk Analysis', icon: Activity },
            { id: 'crispr', label: 'CRISPR Lab', icon: FlaskConical },
            { id: 'report', label: 'Case Study Report', icon: FileText }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "flex items-center gap-3 transition-all relative h-full group",
                activeTab === tab.id ? "text-white" : "text-slate-600 hover:text-slate-400"
              )}
            >
              <tab.icon className={cn("w-4 h-4", activeTab === tab.id ? "text-white" : "text-slate-700 group-hover:text-slate-500")} />
              <span className="text-[10px] font-black uppercase tracking-[0.2em]">{tab.label}</span>
              {activeTab === tab.id && (
                <motion.div 
                  layoutId="activeTabUnderline"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]" 
                />
              )}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-12 custom-scrollbar scroll-smooth">
          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="max-w-4xl mx-auto space-y-12 py-10"
              >
                <div className="text-center space-y-6">
                   <div className="w-20 h-20 rounded-3xl bg-white text-black flex items-center justify-center mx-auto shadow-2xl">
                      <Layout className="w-8 h-8" />
                   </div>
                   <div className="space-y-2">
                     <h2 className="text-4xl font-black text-white uppercase tracking-tighter">HelixLens: Clinical Genomics Lab</h2>
                     <p className="text-slate-500 font-medium uppercase tracking-[0.4em] text-xs">Interactive Genetic Simulation & Learning Platform</p>
                   </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="p-8 bg-white/[0.02] border border-white/5 rounded-3xl space-y-4">
                    <h3 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-3">
                       <span className="w-2 h-2 rounded-full bg-emerald-500" />
                       Learning Objective
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed font-medium">
                      Understand the molecular foundations of clinical genetics. This simulator allows students to explore how pathogenic variants lead to human disease, calculate inheritance risks across three generations, and experiment with virtual CRISPR gene-editing technologies.
                    </p>
                  </div>
                  <div className="p-8 bg-white/[0.02] border border-white/5 rounded-3xl space-y-4">
                    <h3 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-3">
                       <span className="w-2 h-2 rounded-full bg-blue-500" />
                       Educational Engine
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed font-medium">
                      The simulation utilizes real-world genomic datasets and molecular dynamics to provide an accurate representation of genetic interventions. Discover the relationship between DNA sequence changes and resulting protein structural impacts.
                    </p>
                  </div>
                </div>

                <div className="bg-slate-800/50 border border-white/10 p-10 rounded-[3rem] relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-8">
                    <Dna className="w-24 h-24 text-white opacity-5 rotate-12" />
                  </div>
                  <h3 className="text-lg font-black text-white uppercase tracking-widest mb-6">Learning Workflow</h3>
                  <div className="space-y-6">
                    {[
                      { step: '01', title: 'Gene Selection', desc: 'Study pathogenic variants from the curated genomic catalog.' },
                      { step: '02', title: 'Risk Calculation', desc: 'Apply Mendelian laws to family pedigrees to predict inheritance.' },
                      { step: '03', title: 'CRISPR Interaction', desc: 'Design guide RNAs and observe molecular repair pathways in action.' },
                      { step: '04', title: 'Case Synthesis', desc: 'Review findings and summarize the clinical impact of the simulation.' }
                    ].map((step, i) => (
                      <div key={i} className="flex gap-6 items-start">
                        <span className="text-xl font-black text-white/10 shrink-0">{step.step}</span>
                        <div>
                          <h4 className="text-xs font-black text-white uppercase tracking-widest mb-1">{step.title}</h4>
                          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">{step.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-center">
                   <button 
                    onClick={() => setActiveTab('library')}
                    className="px-10 py-4 bg-white text-black rounded-2xl text-[10px] font-black uppercase tracking-[0.4em] hover:scale-105 active:scale-95 transition-all shadow-2xl shadow-white/10"
                   >
                     Initialize Protocol
                   </button>
                </div>
              </motion.div>
            )}

            {activeTab === 'library' && (
              <motion.div
                key="library"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8"
              >
                <div className="flex items-center justify-between">
                  <div className="flex flex-col gap-1">
                    <h2 className="text-3xl font-black text-white tracking-tight leading-none uppercase">Genomic Catalog</h2>
                    <p className="text-slate-500 text-sm font-medium tracking-wide">Registry of pathogenic variants and clinical learning cases.</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <button 
                      onClick={() => setShowAddGene(true)}
                      className="bg-white hover:bg-slate-200 text-black px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-xl shadow-white/5 active:scale-95"
                    >
                      + Entry New Variant
                    </button>
                        <div className="relative group">
                          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 transition-colors group-focus-within:text-white" />
                          <input 
                            type="text" 
                            placeholder="FILTER BY GENE OR CLINICAL PHENOTYPE..." 
                            className="bg-slate-900 border border-slate-800 rounded-xl py-2.5 pl-12 pr-6 text-[10px] font-bold tracking-widest focus:outline-none focus:border-white/20 transition-all w-80 placeholder:text-slate-700 uppercase"
                          />
                        </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {geneLibrary.map(gene => (
                    <button
                      key={gene.id}
                      onClick={() => setSelectedGene(gene)}
                      className={`text-left p-6 rounded-3xl border transition-all group relative overflow-hidden flex flex-col h-48 ${
                        selectedGene.id === gene.id 
                          ? 'bg-white border-white' 
                          : 'bg-slate-800/40 border-slate-700/50 hover:border-slate-500 hover:bg-slate-800/80 shadow-md'
                      }`}
                    >
                      {selectedGene.id === gene.id ? (
                        <div className="absolute top-4 right-4 animate-in fade-in zoom-in duration-300">
                          <CheckCircle2 className="w-5 h-5 text-black" />
                        </div>
                      ) : (
                        <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                           <ArrowRight className="w-4 h-4 text-slate-500" />
                        </div>
                      )}
                      
                      <div className="flex-1">
                        <Dna className={`w-6 h-6 mb-4 transition-transform group-hover:scale-110 ${
                          selectedGene.id === gene.id ? 'text-black' : 'text-slate-500'
                        }`} />
                        <h3 className={`font-black text-xl tracking-tighter ${selectedGene.id === gene.id ? 'text-black' : 'text-white'}`}>
                          {gene.name}
                        </h3>
                        <p className={`text-[10px] font-black uppercase tracking-widest mt-1 ${selectedGene.id === gene.id ? 'text-black/60' : 'text-slate-500'}`}>
                          {gene.disease}
                        </p>
                      </div>
                      
                      <div className="flex items-center gap-2 mt-auto">
                        <div className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest ${
                          selectedGene.id === gene.id ? 'bg-black/10 text-black' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {gene.inheritance?.split(' ')[0]}
                        </div>
                        <div className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest italic ${
                          selectedGene.id === gene.id ? 'bg-black/10 text-black' : 'bg-slate-800 text-slate-400'
                        }`}>
                          P:{gene.penetrance}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
                
                <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 shadow-xl">
                  <div className="flex items-center gap-3 mb-4">
                    <Target className="w-5 h-5 text-sky-400" />
                    <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">Deep Gene Insight: {selectedGene.name}</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="space-y-4">
                      <div className="flex flex-col">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Base Sequence</span>
                          <button 
                            onClick={validateGeneEntry}
                            disabled={isValidating}
                            className="flex items-center h-6 px-2 text-[9px] text-purple-400 hover:text-purple-300 hover:bg-purple-400/10 gap-1.5 transition-colors rounded-md border border-transparent"
                          >
                            {isValidating ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <Sparkles className="w-3 h-3" />
                            )}
                            Verify with Expert AI
                          </button>
                        </div>
                        <div className="font-mono text-[10px] p-3 bg-slate-900/50 rounded-xl break-all line-clamp-6 leading-relaxed border border-slate-800">
                          {selectedGene.sequence}
                        </div>
                      </div>

                      <AnimatePresence>
                        {validationResult && (
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="p-4 bg-slate-900 border border-purple-500/30 rounded-2xl shadow-xl shadow-purple-500/5 relative overflow-hidden"
                          >
                            <div className="absolute top-0 right-0 p-4">
                              <div className={`text-xs font-bold ${validationResult.score > 80 ? 'text-emerald-400' : 'text-amber-400'}`}>
                                AI Confidence: {validationResult.score}%
                              </div>
                            </div>
                            <div className="flex items-center gap-2 mb-3">
                              <div className="p-1.5 bg-purple-500/20 rounded-lg">
                                <BrainCircuit className="w-4 h-4 text-purple-400" />
                              </div>
                              <h4 className="text-sm font-bold text-slate-100">AI Validation Audit</h4>
                            </div>
                            
                            <div className="space-y-3">
                              {validationResult.errors?.length && validationResult.errors.length > 0 && (
                                <div className="space-y-1">
                                  <span className="text-[10px] font-bold text-red-400 uppercase tracking-widest block">Inconsistencies Detected</span>
                                  <ul className="space-y-1">
                                    {validationResult.errors.map((err, i) => (
                                      <li key={i} className="text-[10px] text-slate-300 flex items-start gap-1.5 leading-relaxed">
                                        <AlertCircle className="w-3 h-3 text-red-500 mt-0.5 shrink-0" />
                                        {err}
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                              
                              <div className="space-y-1">
                                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Biological Explanation</span>
                                <p className="text-[10px] text-slate-400 italic leading-relaxed">
                                  {validationResult.explanation}
                                </p>
                              </div>

                              <div className="flex gap-2 pt-2">
                                <button 
                                  className="h-8 text-[10px] bg-purple-600 hover:bg-purple-500 text-white font-bold w-full rounded-lg transition-colors"
                                  onClick={applyCorrections}
                                >
                                  Apply Correction Strategy
                                </button>
                                <button 
                                  className="h-8 text-[10px] bg-transparent border border-slate-700 text-slate-400 hover:text-slate-200 px-3 rounded-lg transition-colors"
                                  onClick={() => setValidationResult(null)}
                                >
                                  Dismiss
                                </button>
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                      {selectedGene.notes && (
                        <div className="p-3 bg-slate-800/30 rounded-xl border border-slate-800/50">
                          <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Expert Notes</span>
                          <p className="text-[10px] text-slate-400 italic font-medium leading-normal">{selectedGene.notes}</p>
                        </div>
                      )}
                    </div>
                    <div className="col-span-2 grid grid-cols-2 gap-4">
                      <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-800 h-full">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Protein Domains</span>
                        <div className="space-y-2">
                          {selectedGene.domains?.map((d, i) => (
                            <div key={i} className="flex items-center justify-between text-[11px]">
                              <span className="text-slate-300 font-medium">{d.name}</span>
                              <span className="text-slate-500 font-mono italic">{d.start}-{d.end} aa</span>
                            </div>
                          ))}
                        </div>
                        {selectedGene.strategy && (
                          <div className="mt-4 pt-4 border-t border-slate-800/50">
                            <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest block mb-1">Recommended strategy</span>
                            <p className="text-[10px] text-slate-400 leading-normal italic">{selectedGene.strategy}</p>
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col gap-4">
                        <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-800">
                          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Population Data</span>
                          <div className="space-y-2">
                             <div className="flex items-center justify-between text-[11px]">
                                <span className="text-slate-400">Prevalence</span>
                                <span className="text-slate-200 font-bold">{selectedGene.prevalence}</span>
                             </div>
                             <div className="flex items-center justify-between text-[11px]">
                                <span className="text-slate-400">Inheritance</span>
                                <span className="text-slate-200 font-bold">{selectedGene.inheritance}</span>
                             </div>
                             <div className="flex items-center justify-between text-[11px]">
                                <span className="text-slate-400">GC Content</span>
                                <span className="text-slate-200 font-bold">{selectedGene.gcContent || 'N/A'}</span>
                             </div>
                             {selectedGene.notes && (
                               <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800/50 mt-1">
                                 <span className="text-slate-400">ACMG Class</span>
                                 <span className="text-emerald-400 font-black tracking-tighter uppercase">Pathogenic (P)</span>
                               </div>
                             )}
                          </div>
                        </div>
                        {selectedGene.mutationType && (
                          <div className="p-4 bg-purple-500/5 rounded-xl border border-purple-500/20">
                            <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest block mb-1">Pathogenic Mechanism</span>
                            <span className="text-xs font-black text-slate-100">{selectedGene.mutationType}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'risk' && (
              <motion.div
                key="risk"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div>
                  <h2 className="text-2xl font-black text-white tracking-tight italic">Genetic Risk & Pedigree Profiler</h2>
                  <p className="text-slate-400 text-sm mt-1">Analyze inheritance probabilities by mapping family phenotypes against the {selectedGene.name} variant.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                  <div className="lg:col-span-3">
                    <PedigreeChart members={familyMembers} />
                    
                    <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
                      {familyMembers.map(member => (
                        <div key={member.id} className="bg-slate-900 border border-slate-800 p-3 rounded-xl flex flex-col justify-between group gap-2">
                          <div>
                            <span className="text-[10px] font-bold text-slate-400 uppercase block leading-none mb-1">{member.relation}</span>
                            <span className="text-xs font-bold text-slate-100">{member.name}</span>
                          </div>
                          <div className="flex items-center gap-2 mt-1 border-t border-slate-800 pt-2">
                             <button
                               onClick={() => toggleMemberStatus(member.id, 'affected')}
                               className={`px-2 py-1 flex-1 rounded text-[9px] font-bold uppercase transition-colors ${
                                 member.affected ? 'bg-red-500/20 text-red-400 border border-red-500/30' : 'bg-slate-800 text-slate-500 hover:text-slate-300'
                               }`}
                             >
                               Affected
                             </button>
                             <button
                               onClick={() => toggleMemberStatus(member.id, 'carrier')}
                               className={`px-2 py-1 flex-1 rounded text-[9px] font-bold uppercase transition-colors ${
                                 member.carrier ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-slate-800 text-slate-500 hover:text-slate-300'
                               }`}
                             >
                               Carrier
                             </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="lg:col-span-2">
                    <RiskDashboard analysis={riskAnalysis} />
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'crispr' && (
              <motion.div
                key="crispr"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-8"
              >
                {/* 3D Viewport Column */}
                <div className="lg:col-span-8 flex flex-col gap-6">
                  {/* DNA View */}
                  <div className="bg-slate-900/50 rounded-3xl border border-slate-800/80 relative h-[450px] overflow-hidden flex flex-col group shadow-2xl">
                    <div className="absolute top-6 left-6 z-10 flex flex-col gap-2 pointer-events-none">
                        <div className="bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 flex items-center gap-2">
                          <Scaling className="w-3 h-3 text-purple-400" />
                          <span className="text-[10px] font-bold text-slate-200 uppercase tracking-widest italic">3D DNA Lab</span>
                        </div>
                        {timelineStep > 0 && (
                          <motion.div 
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="bg-emerald-500/20 backdrop-blur-md px-3 py-1.5 rounded-xl border border-emerald-500/40 flex items-center gap-2"
                          >
                            <Activity className="w-3 h-3 text-emerald-400 animate-pulse" />
                            <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">
                              {timelineStep === 1 ? 'gRNA SCANNING...' : timelineStep === 2 ? 'DNA CLEAVAGE' : 'REPAIR COMPLETE'}
                            </span>
                          </motion.div>
                        )}
                    </div>

                    <DNA3DViewer 
                      sequence={selectedGene.sequence} 
                      timelineStep={timelineStep}
                      mutationType={simulation?.mutationType || null}
                      cutPosition={simulation?.cutPosition}
                      highlights={
                        simulation?.cutPosition 
                        ? [
                            { start: Math.max(0, simulation.cutPosition - 17), end: simulation.cutPosition + 3, label: 'gRNA Target', color: 'border-purple-500' },
                            { start: simulation.cutPosition + 3, end: simulation.cutPosition + 6, label: 'PAM (NGG)', color: 'border-amber-500' },
                            { start: 0, end: selectedGene.sequence?.length || 0, label: 'Reference DNA', color: 'border-slate-500' }
                          ]
                        : [{ start: 0, end: selectedGene.sequence?.length || 0, label: 'Reference DNA', color: 'border-slate-500' }]
                      }
                    />

                    {/* Reset Button */}
                    <div className="absolute bottom-6 left-6 z-10">
                      <button 
                        onClick={() => { setTimelineStep(0); setSimulation(null); }}
                        className="bg-slate-900/80 backdrop-blur-md border border-slate-800 p-2 rounded-xl text-slate-400 hover:text-white transition-all pointer-events-auto shadow-lg"
                      >
                        <RefreshCcw className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Protein View */}
                  {simulation && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl overflow-hidden relative"
                    >
                      <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-3">
                          <Beaker className="w-5 h-5 text-emerald-400" />
                          <h3 className="font-black text-slate-100 uppercase tracking-widest">Functional Protein Analysis</h3>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${
                          simulation.impact.includes('Frameshift') ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'
                        }`}>
                          {simulation.impact}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                          <Protein3DViewer protein={simulation.mutatedProtein} diffs={proteinDiffs} />
                        </div>
                        <div className="space-y-6">
                          <div className="p-4 bg-slate-900/50 rounded-2xl border border-slate-800 shadow-sm">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-3">Academic Note: Structural Impact</span>
                            <p className="text-xs text-slate-300 leading-relaxed italic">
                              {simulation.prediction.functionalImpact}
                            </p>
                            <div className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-4">
                               <div className="flex flex-col">
                                  <span className="text-[9px] text-slate-500 uppercase">Residue Count</span>
                                  <span className="text-sm font-black text-slate-200">{simulation.mutatedProtein.length} aa</span>
                               </div>
                               <div className="flex flex-col">
                                  <span className="text-[9px] text-slate-500 uppercase">Mutation Type</span>
                                  <span className="text-sm font-black text-purple-400">{simulation.mutationType.toUpperCase()}</span>
                               </div>
                            </div>
                          </div>
                          <div className="space-y-2">
                             <div className="flex items-center gap-2 mb-2">
                                <Sparkles className="w-3 h-3 text-purple-400" />
                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Precision Metrics</span>
                             </div>
                             <div className="grid grid-cols-2 gap-3">
                                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl">
                                   <span className="text-[9px] text-slate-500 uppercase block">Frameshift Prob.</span>
                                   <span className="text-lg font-black text-red-500">{(simulation.prediction.frameshiftProbability * 100).toPrecision(3)}%</span>
                                </div>
                                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl">
                                   <span className="text-[9px] text-slate-500 uppercase block">Functional Loss</span>
                                   <span className="text-lg font-black text-amber-500">{(simulation.prediction.predictedKnockoutRate * 100).toPrecision(3)}%</span>
                                </div>
                             </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Lab Controls Column */}
                <div className="lg:col-span-4 flex flex-col gap-6 h-[calc(100vh-12rem)] overflow-y-auto pr-2 custom-scrollbar">
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shrink-0">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Guide RNA Design</h3>
                      <div className="px-2 py-0.5 rounded bg-purple-500/20 border border-purple-500/50 text-[8px] font-black text-purple-400 uppercase">AI-Ranked</div>
                    </div>
                    <div className="space-y-3">
                       {guides.slice(0, 4).map((guide, idx) => (
                         <div key={idx} className="bg-slate-950/80 border border-slate-800 p-4 rounded-2xl hover:border-purple-500/50 transition-all group shadow-xl">
                            <div className="flex items-center justify-between mb-3 text-[10px]">
                               <div className="flex items-center gap-2">
                                  <div className="w-5 h-5 rounded bg-purple-600 flex items-center justify-center text-white font-black">
                                    {guide.rank}
                                  </div>
                                  <span className="font-bold text-slate-300">Target Segment</span>
                               </div>
                               <span className="font-mono text-slate-500">PAM: {guide.pam}</span>
                            </div>
                            <div className="font-mono text-[11px] text-slate-100 mb-4 break-all bg-slate-900 p-2.5 rounded-xl border border-slate-800 tracking-wide selection:bg-purple-500">
                               {guide.sequence}
                            </div>
                            <div className="grid grid-cols-2 gap-4 mb-5">
                               <div className="space-y-1">
                                  <span className="text-[8px] text-slate-500 uppercase font-black tracking-tighter">Cutting Efficiency</span>
                                  <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
                                    <div className="bg-emerald-500 h-full" style={{ width: `${guide.efficiencyScore * 100}%` }} />
                                  </div>
                                  <span className="text-xs font-black text-emerald-400">{(guide.efficiencyScore * 100).toFixed(1)}%</span>
                               </div>
                               <div className="space-y-1">
                                  <span className="text-[8px] text-slate-500 uppercase font-black tracking-tighter">Off-Target Risk</span>
                                  <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
                                    <div className="bg-amber-500 h-full" style={{ width: `${guide.mismatchPotential * 100}%` }} />
                                  </div>
                                  <span className={`text-xs font-black ${guide.mismatchPotential > 0.3 ? 'text-red-400' : 'text-slate-300'}`}>
                                    {(guide.mismatchPotential * 100).toFixed(1)}%
                                  </span>
                               </div>
                            </div>
                            <div className="flex gap-2">
                               <button 
                                 onClick={() => runSimulation(guide, 'knockout')}
                                 className="flex-[1.5] bg-red-600/10 hover:bg-red-600 text-red-500 hover:text-white border border-red-600/30 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                               >
                                 Knockout
                               </button>
                               <button 
                                 onClick={() => runSimulation(guide, 'correction')}
                                 className="flex-[1] bg-emerald-600/10 hover:bg-emerald-600 text-emerald-500 hover:text-white border border-emerald-600/30 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                               >
                                 Fix
                               </button>
                            </div>
                         </div>
                       ))}
                    </div>
                  </div>

                  {simulation && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-slate-900 border border-slate-800 rounded-2xl p-5"
                    >
                      <div className="flex items-center gap-2 mb-4">
                        <Microscope className="w-4 h-4 text-sky-400" />
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">In Silico Prediction</h3>
                      </div>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                           <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                              <span className="text-[9px] text-slate-500 uppercase font-bold tracking-tighter block mb-1">NHEJ Repair</span>
                              <span className="text-xl font-black text-red-500">{(simulation.prediction.nhejProbability * 100).toFixed(0)}%</span>
                           </div>
                           <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                              <span className="text-[9px] text-slate-500 uppercase font-bold tracking-tighter block mb-1">HDR Repair</span>
                              <span className="text-xl font-black text-emerald-500">{(simulation.prediction.hdrProbability * 100).toFixed(0)}%</span>
                           </div>
                        </div>
                        <div className="p-4 bg-purple-500/5 rounded-2xl border border-purple-500/20">
                           <div className="flex items-center gap-2 mb-2">
                              <BrainCircuit className="w-3 h-3 text-purple-400" />
                              <span className="text-[10px] font-black text-purple-300 uppercase tracking-widest italic">AI Interpretation</span>
                           </div>
                           <p className="text-[10px] text-slate-400 leading-relaxed italic">
                              {simulation.prediction.biologicalInterpretation}
                           </p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                  
                  {/* Additional Safety Layer in Lab */}
                  <div className="p-5 bg-amber-500/10 rounded-2xl border border-amber-500/20 flex gap-4">
                     <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
                     <div className="space-y-1">
                        <h4 className="text-[10px] font-black text-amber-300 uppercase tracking-widest">Off-Target Notice</h4>
                        <p className="text-[9px] text-amber-400/80 leading-normal font-medium">
                          High mismatch potential detected in homologous pseudogenes. Proceed with high-fidelity Cas9 variants for clinical validation.
                        </p>
                     </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'report' && (
              <motion.div
                key="report"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <ScientificReport 
                  gene={selectedGene} 
                  simulation={simulation} 
                  guide={selectedGuide}
                  familyMembers={familyMembers} 
                />
              </motion.div>
            )}

            {showAddGene && (
              <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col">
                  <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900">
                    <h3 className="text-lg font-black text-white flex items-center gap-2">
                       <Dna className="w-5 h-5 text-purple-400" />
                       Add Custom Disease
                    </h3>
                    <div className="flex items-center gap-3">
                      <button 
                         onClick={() => generateGeneDetails(newGene.name || '', newGene.disease || '')}
                         disabled={!newGene.name || !newGene.disease || isGenerating}
                         className="flex items-center gap-2 px-3 py-1.5 bg-purple-500/20 text-purple-400 border border-purple-500/50 rounded-lg text-xs font-bold hover:bg-purple-500/30 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                       >
                         {isGenerating ? <Activity className="w-3.5 h-3.5 animate-spin" /> : <BrainCircuit className="w-3.5 h-3.5" />}
                         {isGenerating ? 'Synthesizing...' : 'AI Auto-Fill'}
                      </button>
                      <button onClick={() => setShowAddGene(false)} className="text-slate-500 hover:text-white">
                        ✕
                      </button>
                    </div>
                  </div>
                  <div className="p-6 space-y-4 overflow-y-auto max-h-[70vh] custom-scrollbar">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-400 uppercase">Disease Name</label>
                        <input 
                          type="text" 
                          value={newGene.disease || ''}
                          onChange={e => setNewGene({...newGene, disease: e.target.value})}
                          placeholder="e.g. Tay-Sachs"
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-sm focus:border-purple-500 outline-none"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-400 uppercase">Gene Symbol</label>
                        <input 
                          type="text" 
                          value={newGene.name || ''}
                          onChange={e => setNewGene({...newGene, name: e.target.value})}
                          placeholder="e.g. HEXA"
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-sm focus:border-purple-500 outline-none uppercase"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-400 uppercase">DNA Sequence</label>
                      <textarea 
                        value={newGene.sequence || ''}
                        onChange={e => setNewGene({...newGene, sequence: e.target.value.toUpperCase().replace(/[^ATCG\s]/g, '')})}
                        placeholder="ATCG..."
                        rows={4}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-sm font-mono focus:border-purple-500 outline-none custom-scrollbar"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-400 uppercase">Inheritance</label>
                        <select 
                          value={newGene.inheritance || 'Autosomal Dominant'}
                          onChange={e => setNewGene({...newGene, inheritance: e.target.value as any})}
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-sm focus:border-purple-500 outline-none"
                        >
                          <option value="Autosomal Dominant">Autosomal Dominant</option>
                          <option value="Autosomal Recessive">Autosomal Recessive</option>
                          <option value="X-Linked Recessive">X-Linked Recessive</option>
                          <option value="X-Linked Dominant">X-Linked Dominant</option>
                          <option value="Mitochondrial">Mitochondrial</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-400 uppercase">Penetrance (0.0 - 1.0)</label>
                        <input 
                          type="number" 
                          step="0.1"
                          min="0"
                          max="1"
                          value={newGene.penetrance}
                          onChange={e => setNewGene({...newGene, penetrance: parseFloat(e.target.value)})}
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-sm focus:border-purple-500 outline-none"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-400 uppercase">Prevalence</label>
                      <input 
                        type="text" 
                        value={newGene.prevalence || ''}
                        onChange={e => setNewGene({...newGene, prevalence: e.target.value})}
                        placeholder="e.g. 1 in 10000"
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-sm focus:border-purple-500 outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-400 uppercase">Protein Domains</label>
                      <div className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-sm max-h-32 overflow-y-auto">
                        {newGene.domains && newGene.domains.length > 0 ? (
                          newGene.domains.map((domain, idx) => (
                            <div key={idx} className="flex justify-between items-center py-1 border-b border-slate-800/50 last:border-0">
                              <span className="text-slate-300 font-medium">{domain.name}</span>
                              <span className="text-slate-500 font-mono text-xs">{domain.start}-{domain.end} aa</span>
                            </div>
                          ))
                        ) : (
                          <div className="text-slate-500 text-sm italic py-2 text-center">
                            No domains added. Use AI Auto-Fill to generate.
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-400 uppercase">Description / Details</label>
                      <textarea 
                        value={newGene.description || ''}
                        onChange={e => setNewGene({...newGene, description: e.target.value})}
                        rows={2}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-sm focus:border-purple-500 outline-none custom-scrollbar"
                      />
                    </div>
                  </div>
                  <div className="p-4 border-t border-slate-800 flex justify-end gap-3 bg-slate-900">
                    <button 
                      onClick={() => setShowAddGene(false)}
                      className="px-4 py-2 rounded-xl text-sm font-bold text-slate-400 hover:text-white transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={handleAddGene}
                      disabled={!newGene.name || !newGene.disease || !newGene.sequence}
                      className="bg-purple-600 hover:bg-purple-500 disabled:opacity-50 disabled:cursor-not-allowed text-white px-6 py-2 rounded-xl text-sm font-bold transition-all shadow-lg shadow-purple-500/20"
                    >
                      Save to Library
                    </button>
                  </div>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer / Ethics Module */}
        <footer className="h-12 border-t border-slate-800 bg-slate-900 flex items-center justify-between px-8 text-[9px] font-bold text-slate-500 uppercase tracking-widest bg-slate-900/40">
           <div className="flex items-center gap-6">
           </div>
           <div className="flex items-center gap-4">
              <span className="text-amber-500/80">Biological Sandbox | Not for clinical diagnostic use</span>
              <div className="h-4 w-px bg-slate-800" />
              <span>&copy; 2026 HelixLens Genomic Intelligence</span>
           </div>
        </footer>
      </main>
    </div>
  );
};
