import React from 'react';
import { motion } from 'motion/react';
import { OffTargetSite } from '../types/bio';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../../components/ui/tooltip';

interface OffTargetHeatmapProps {
  sequence: string;
  offTargets: OffTargetSite[];
}

export const OffTargetHeatmap: React.FC<OffTargetHeatmapProps> = ({ sequence, offTargets }) => {
  const segments = 100;
  const seq = sequence || '';
  const segmentSize = Math.ceil(seq.length / segments);
  
  const heatmapData = Array.from({ length: segments }).map((_, i) => {
    const start = i * segmentSize;
    const end = start + segmentSize;
    const targetsInRange = offTargets.filter(ot => ot.position >= start && ot.position < end);
    
    let riskScore = 0;
    targetsInRange.forEach(ot => {
      if (ot.risk === 'High') riskScore += 3;
      else if (ot.risk === 'Medium') riskScore += 2;
      else riskScore += 1;
    });
    
    return {
      index: i,
      riskScore,
      count: targetsInRange.length,
      range: `${start}-${end}`
    };
  });

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-[10px] font-bold text-slate-500 uppercase">Genomic Risk Heatmap</span>
        <div className="flex gap-2 items-center">
          <div className="flex gap-1 items-center">
            <div className="w-2 h-2 bg-slate-800 rounded-sm"></div>
            <span className="text-[8px] text-slate-600">Safe</span>
          </div>
          <div className="flex gap-1 items-center">
            <div className="w-2 h-2 bg-red-500 rounded-sm"></div>
            <span className="text-[8px] text-slate-600">High Risk</span>
          </div>
        </div>
      </div>
      
      <div className="flex gap-[1px] h-4 w-full bg-slate-900 rounded-sm overflow-hidden border border-slate-800 p-[1px]">
        <TooltipProvider>
          {heatmapData.map((data) => (
            <React.Fragment key={data.index}>
              <Tooltip>
                <TooltipTrigger 
                  render={
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: data.index * 0.005 }}
                      className={cn(
                        "flex-1 h-full transition-colors cursor-help",
                        data.riskScore === 0 ? "bg-slate-800/50" :
                        data.riskScore < 2 ? "bg-amber-500/40" :
                        data.riskScore < 5 ? "bg-orange-500/60" :
                        "bg-red-500"
                      )}
                    />
                  }
                />
                <TooltipContent className="bg-slate-900 border-slate-800 text-[10px]">
                  <p className="font-bold">Region: {data.range} bp</p>
                  <p>{data.count} potential off-targets</p>
                  <p className="text-red-400">Risk Score: {data.riskScore}</p>
                </TooltipContent>
              </Tooltip>
            </React.Fragment>
          ))}
        </TooltipProvider>
      </div>
    </div>
  );
};
