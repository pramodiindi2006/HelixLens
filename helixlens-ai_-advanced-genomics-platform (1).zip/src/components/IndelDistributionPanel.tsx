import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, BarChart4, Percent } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SimulationResult } from '../types/bio';

interface IndelDistributionPanelProps {
  simulation: SimulationResult | null;
}

export function IndelDistributionPanel({ simulation }: IndelDistributionPanelProps) {
  if (!simulation || simulation.mutationType !== 'knockout') return null;

  // Realistic mock data for a standard Cas9 blunt end cut repaired via NHEJ
  const indels = [
    { label: '+1 bp', value: 39, type: 'frameshift', color: 'bg-purple-500' },
    { label: '-1 bp', value: 24, type: 'frameshift', color: 'bg-purple-500' },
    { label: '-2 bp', value: 12, type: 'frameshift', color: 'bg-purple-500' },
    { label: '-3 bp', value: 11, type: 'in-frame', color: 'bg-emerald-500' },
    { label: '+2 bp', value: 5, type: 'frameshift', color: 'bg-purple-500' },
    { label: '-4 bp', value: 3, type: 'frameshift', color: 'bg-purple-500' },
    { label: '-6 bp', value: 4, type: 'in-frame', color: 'bg-emerald-500' },
    { label: 'Other', value: 2, type: 'mixed', color: 'bg-slate-500' }
  ];

  const frameshiftPercent = 85; 
  const inFramePercent = 15; 
  const functionalKORate = frameshiftPercent + 5; // Includes frameshifts + structurally disruptive in-frame mutations

  const maxValue = Math.max(...indels.map(i => i.value));

  return (
    <Card className="bg-slate-800/40 backdrop-blur-xl border border-slate-700/50 shadow-xl overflow-hidden mt-6 relative group">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
      <CardHeader className="pb-2 bg-slate-800/10 border-b border-slate-800/50 relative z-10">
        <CardTitle className="text-sm font-bold flex items-center gap-2">
          <BarChart4 className="w-4 h-4 text-purple-400" />
          Predicted Indel Distribution (NHEJ Repair)
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Chart Section */}
          <div className="space-y-4">
            <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Indel Profile (Relative Frequency)</h3>
            <div className="flex h-32 items-end gap-2 border-b border-slate-700/50 pb-2">
              {indels.map((indel, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center justify-end group">
                  <div className="text-[9px] font-bold text-slate-400 mb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {indel.value}%
                  </div>
                  <div 
                    className={cn("w-full max-w-[24px] rounded-t-sm transition-all duration-500 group-hover:opacity-80", indel.color)} 
                    style={{ height: `${(indel.value / maxValue) * 100}%` }}
                  />
                  <div className="text-[9px] text-slate-500 mt-2 font-mono rotate-[-45deg] origin-top-left -ml-2 whitespace-nowrap">
                    {indel.label}
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-center gap-4 mt-8 pt-4">
              <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest text-slate-400">
                <div className="w-2 h-2 rounded-full bg-purple-500" /> Frameshift
              </div>
              <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest text-slate-400">
                <div className="w-2 h-2 rounded-full bg-emerald-500" /> In-Frame
              </div>
            </div>
          </div>

          {/* Metrics Section */}
          <div className="flex flex-col justify-center space-y-4">
            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 flex items-center justify-between shadow-inner">
              <div>
                <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Frameshift Mutations</h4>
                <p className="text-[10px] text-slate-400 mt-1">Disrupts reading frame</p>
              </div>
              <div className="text-2xl font-black text-purple-400">{frameshiftPercent}%</div>
            </div>

            <div className="p-4 rounded-xl border border-slate-800 bg-slate-900/50 flex items-center justify-between shadow-inner">
              <div>
                <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">In-Frame Mutations</h4>
                <p className="text-[10px] text-slate-400 mt-1">Preserves reading frame</p>
              </div>
              <div className="text-2xl font-black text-emerald-400">{inFramePercent}%</div>
            </div>

            <div className="p-4 rounded-xl border border-emerald-500/20 bg-emerald-500/5 flex items-center justify-between">
              <div>
                <h4 className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest flex items-center gap-1.5">
                  <Activity className="w-3 h-3" /> Predicted Knockout
                </h4>
                <p className="text-[10px] text-emerald-400/70 mt-1">Functional KO rate</p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-black text-emerald-400">{functionalKORate - 3}–{functionalKORate + 2}%</div>
                <div className="text-[10px] text-emerald-500/80 font-bold uppercase tracking-widest mt-1">(High Confidence)</div>
              </div>
            </div>
          </div>

        </div>
      </CardContent>
    </Card>
  );
}
