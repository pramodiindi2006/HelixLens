import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Beaker, ArrowRight } from 'lucide-react';
import { compareProteins } from '../lib/bio-utils';
import { cn } from '@/lib/utils';
import { SimulationResult, GeneData } from '../types/bio';

interface ProteinImpactPanelProps {
  simulation: SimulationResult;
  gene: GeneData;
}

export function ProteinImpactPanel({ simulation, gene }: ProteinImpactPanelProps) {
  const { originalProtein, mutatedProtein, impact, mutationType, originalDNA, mutatedDNA, cutPosition } = simulation;
  const isFrameshift = mutationType === 'knockout';
  const diffs = compareProteins(originalProtein, mutatedProtein, isFrameshift);
  
  const CHUNK_SIZE = 35;
  const chunks = [];
  for (let i = 0; i < diffs.length; i += CHUNK_SIZE) {
    chunks.push(diffs.slice(i, i + CHUNK_SIZE));
  }

  // Calculate strict deterministic output for knockout
  const isKnockout = mutationType === 'knockout';
  const deletedBase = isKnockout ? originalDNA[cutPosition] : null;
  const stopCodonPos = mutatedProtein.indexOf('*');

  // Generate DNA alignment strings for knockout
  const origDNASnippet = originalDNA;
  const mutDNASnippet = mutatedDNA.substring(0, cutPosition) + '-' + mutatedDNA.substring(cutPosition);
  const markerSnippet = ' '.repeat(cutPosition) + '^';

  // Classification Logic
  let classification = "Observed outcome: NHEJ in-frame (partial/uncertain)";
  let classificationColor = "text-amber-400";
  let classificationBg = "bg-amber-500/10 border-amber-500/20";
  let domainImpactText = "";
  let explanationText = "";

  if (isFrameshift) {
    const retainedLength = stopCodonPos !== -1 ? stopCodonPos : mutatedProtein.length;
    classification = "Observed outcome: NHEJ frameshift (likely loss-of-function (high-confidence knockout))";
    classificationColor = "text-red-400";
    classificationBg = "bg-red-500/10 border-red-500/20";
    explanationText = "Frameshift mutation disrupts the reading frame, leading to premature termination and loss of protein function.";

    if (gene.domains && gene.domains.length > 0) {
      // Find domains after the truncation
      const keptDomains = gene.domains.filter(d => d.end <= retainedLength);
      const lostDomains = gene.domains.filter(d => d.start > retainedLength);
      const partiallyLostDomains = gene.domains.filter(d => d.start <= retainedLength && d.end > retainedLength);

      const allDisrupted = [...partiallyLostDomains, ...lostDomains];

      if (allDisrupted.length > 0) {
        let domainStr = "";
        if (keptDomains.length > 0) {
          const lastKept = keptDomains[keptDomains.length - 1].name.replace(' pocket', ' region').toLowerCase();
          const joinedNames = allDisrupted.map(d => d.name).join(' and ');
          const disruptedStr = allDisrupted.length > 2 
            ? `all major downstream functional domains (${allDisrupted.map(d => d.name).join(', ')})`
            : `the ${joinedNames}`;
          const proteinName = gene.name === 'HBB' ? 'hemoglobin' : gene.name;
          
          if (gene.name === 'CFTR' && joinedNames === 'TMD2 and NBD2') {
            domainStr = `Frameshift occurs downstream of the ${lastKept} but disrupts critical C-terminal domains (TMD2 and NBD2), impairing channel gating and ion transport.`;
          } else {
            domainStr = `Frameshift occurs downstream of the ${lastKept} but disrupts ${disruptedStr}, likely affecting ${proteinName} stability and function.`;
          }
        } else {
          domainStr = `Truncation removes critical downstream regions: ${allDisrupted.map(d => d.name).join(', ')}.`;
        }

        const ratio = retainedLength / originalProtein.length;
        if (ratio < 0.5) {
           domainStr += " Early truncation likely triggers nonsense-mediated mRNA decay (NMD), further reducing protein expression.";
        }
        domainImpactText = domainStr.trim();
      }
    }
  } else if (mutationType === 'correction' || mutationType === 'knockin') {
    classification = "Observed outcome: HDR (correct edit)";
    classificationColor = "text-emerald-400";
    classificationBg = "bg-emerald-500/10 border-emerald-500/20";
    explanationText = `HDR repair restores the full-length functional protein (~${originalProtein.length} AA) without truncation.`;
  } else {
    classification = "Observed outcome: NHEJ in-frame (partial/uncertain)";
    explanationText = "In-frame mutation alters the localized protein sequence but preserves the global reading frame. The broader functional impact is partial or uncertain.";
  }

  return (
    <Card className="bg-slate-800/40 backdrop-blur-xl border border-slate-700/50 border-l-4 border-l-emerald-500 shadow-xl overflow-hidden relative group">
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
      <CardHeader className="pb-2 bg-slate-800/10 border-b border-slate-800/50 relative z-10">
        <CardTitle className="text-sm font-bold flex items-center gap-2">
          <Beaker className="w-4 h-4 text-emerald-400" />
          Protein Impact Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4 space-y-6">
        {isKnockout && (
          <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-800 font-mono text-sm space-y-4 text-slate-300 shadow-inner">
            <div>
              <span className="text-emerald-400 font-bold">A. Cut site index:</span> {cutPosition}
              <span className="ml-3 inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                ✓ PAM Found (NGG)
              </span>
            </div>
            <div>
              <span className="text-emerald-400 font-bold">B. Deleted base:</span> {deletedBase}
            </div>
            <div>
              <span className="text-emerald-400 font-bold">C. Original DNA:</span>
              <div className="break-all mt-1 text-slate-500">{originalDNA}</div>
            </div>
            <div>
              <span className="text-emerald-400 font-bold">D. Edited DNA:</span>
              <div className="break-all mt-1 text-slate-500">{mutatedDNA}</div>
            </div>
            <div>
              <span className="text-emerald-400 font-bold">E. DNA alignment:</span>
              <pre className="mt-1 overflow-x-auto pb-2">
Original:  {origDNASnippet}
Edited:    {mutDNASnippet}
           {markerSnippet}
           {' '.repeat(Math.max(0, cutPosition - 5))}(deleted {deletedBase})
              </pre>
            </div>
            <div>
              <span className="text-emerald-400 font-bold">F. Protein sequences:</span>
              <div className="mt-1 break-all">Original: {originalProtein}</div>
              <div className="mt-1 break-all">Edited:   {mutatedProtein}</div>
            </div>
            <div>
              <span className="text-emerald-400 font-bold">G. First STOP codon position:</span> Amino Acid {stopCodonPos !== -1 ? stopCodonPos + 1 : 'N/A'}
            </div>
            <div>
              <span className="text-emerald-400 font-bold">H. Explanation:</span> 1 bp deletion → frameshift → premature stop → likely loss-of-function (high-confidence knockout)
            </div>
          </div>
        )}

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Sequence Alignment</label>
            <span className="text-[10px] text-slate-500">{originalProtein.length} AA → {isFrameshift ? mutatedProtein.length : originalProtein.length} AA</span>
          </div>
          <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-800 font-mono text-sm overflow-x-auto pb-4 shadow-inner">
            {isFrameshift && diffs.findIndex(d => d.type === 'frameshift') !== -1 ? (() => {
              const divergenceIndex = diffs.findIndex(d => d.type === 'frameshift');
              const origStr = originalProtein;
              const matchPipes = '|'.repeat(divergenceIndex);
              const editedMatchStr = mutatedProtein.substring(0, divergenceIndex);
              const shiftedStr = mutatedProtein.substring(divergenceIndex);

              // Generate coordinate ruler
              let rulerStr = '';
              for (let i = 1; i <= origStr.length; i++) {
                if (i === 1 || i % 10 === 0) {
                  const numStr = i.toString();
                  rulerStr += numStr;
                  i += numStr.length - 1;
                } else {
                  rulerStr += ' ';
                }
              }
              rulerStr = rulerStr.substring(0, origStr.length);

              return (
                <div className="min-w-max text-slate-300 whitespace-pre">
                  <div className="flex gap-4 mb-1 text-[10px] text-slate-500">
                    <span className="w-16 shrink-0"></span>
                    <span>{rulerStr}</span>
                  </div>
                  <div className="flex gap-4 mb-1">
                    <span className="w-16 text-slate-500 shrink-0">Original:</span>
                    <span>{origStr}</span>
                  </div>
                  <div className="flex gap-4 mb-1">
                    <span className="w-16 shrink-0"></span>
                    <span className="text-slate-500">{matchPipes}</span>
                  </div>
                  <div className="flex gap-4 mb-6">
                    <span className="w-16 text-emerald-500 shrink-0">Edited:</span>
                    <span>{editedMatchStr}</span>
                  </div>
                  
                  <div className="flex gap-4 mb-4">
                    <span className="w-16 shrink-0"></span>
                    <span>
                      {' '.repeat(divergenceIndex)}
                      <span className="text-yellow-400 font-bold">↓ FRAMESHIFT</span>
                    </span>
                  </div>

                  <div className="flex gap-4">
                    <span className="w-16 text-emerald-500 shrink-0">Edited:</span>
                    <span>
                      {' '.repeat(divergenceIndex)}
                      <span className="text-slate-300">{shiftedStr.replace('*', '')}</span>
                      {shiftedStr.includes('*') && <span className="text-red-500 font-bold">*</span>}
                    </span>
                  </div>
                </div>
              );
            })() : (
              chunks.map((chunk, chunkIdx) => (
                <div key={chunkIdx} className="mb-6 last:mb-0 min-w-max text-sm">
                  <div className="flex gap-0.5 mb-1 text-[10px] text-slate-500">
                    <span className="w-16 shrink-0"></span>
                    {chunk.map((_, i) => {
                      const pos = chunkIdx * CHUNK_SIZE + i + 1;
                      return (
                        <span key={`coord-${i}`} className="w-3 text-center">
                          {pos === 1 || pos % 10 === 0 ? pos : ''}
                        </span>
                      );
                    })}
                  </div>
                  <div className="flex gap-0.5 mb-1">
                    <span className="w-16 text-slate-500 shrink-0">Original:</span>
                    {chunk.map((diff, i) => (
                      <span key={`orig-${i}`} className={cn("w-3 text-center", diff.type === 'insertion' ? "text-slate-600" : "text-slate-300")}>
                        {diff.char1}
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-0.5 mb-1">
                    <span className="w-16 shrink-0"></span>
                    {chunk.map((diff, i) => (
                      <span key={`mid-${i}`} className="w-3 text-center text-slate-600">
                        {diff.type === 'match' ? '|' : diff.type === 'mismatch' ? ':' : ' '}
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-0.5">
                    <span className="w-16 text-emerald-500 shrink-0">Mutated:</span>
                    {chunk.map((diff, i) => (
                      <span 
                        key={`mut-${i}`} 
                        className={cn(
                          "w-3 text-center rounded",
                          diff.type === 'match' ? "text-emerald-400" : 
                          diff.type === 'mismatch' ? "bg-amber-500/20 text-amber-400 font-bold" :
                          diff.type === 'insertion' ? "bg-blue-500/20 text-blue-400 font-bold" :
                          "bg-red-500/20 text-red-400 font-bold"
                        )}
                      >
                        {diff.char2}
                      </span>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700/50 space-y-4 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <p className="text-xs font-bold text-slate-300 uppercase tracking-tighter">Protein Impact Classification</p>
            </div>
            <span className={cn("px-2 py-1 rounded text-[10px] font-bold border uppercase", classificationColor, classificationBg)}>
              {classification}
            </span>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            {explanationText}
            {domainImpactText && <strong className="block mt-2 text-red-400 font-medium">{domainImpactText}</strong>}
          </p>

          {gene.domains && gene.domains.length > 0 && (
            <div className="mt-4 border-t border-slate-800/50 pt-4">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Functional Domains Map ({gene.name})</p>
              <div className="relative h-6 bg-slate-700 rounded-sm overflow-hidden flex">
                {gene.domains.map((domain, idx) => {
                  const width = ((domain.end - domain.start + 1) / originalProtein.length) * 100;
                  // Alternate colors for domains
                  const colors = ['bg-blue-500/30 border-blue-500/50 text-blue-300', 'bg-purple-500/30 border-purple-500/50 text-purple-300', 'bg-emerald-500/30 border-emerald-500/50 text-emerald-300'];
                  const colorClass = colors[idx % colors.length];
                  
                  return (
                    <div 
                      key={idx}
                      className={cn("h-full border-r last:border-r-0 flex items-center justify-center overflow-hidden whitespace-nowrap", colorClass)}
                      style={{ width: `${width}%` }}
                      title={`${domain.name} (AA ${domain.start}-${domain.end})`}
                    >
                      <span className="text-[8px] font-bold px-1">{domain.name}</span>
                    </div>
                  );
                })}

                {/* Show truncation point if applicable */}
                {isFrameshift && diffs.findIndex(d => d.type === 'frameshift') !== -1 && (
                  <div 
                    className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10"
                    style={{ left: `${(diffs.findIndex(d => d.type === 'frameshift') / originalProtein.length) * 100}%` }}
                  >
                    <div className="absolute top-0 -translate-x-1/2 -translate-y-full pb-1 pointer-events-none">
                      <span className="bg-red-500 text-white text-[8px] font-bold px-1 py-0.5 rounded shadow-lg whitespace-nowrap">
                        Frameshift Site
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-4 text-[8px] font-bold uppercase tracking-widest text-slate-600">
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Match
          </div>
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            Substitution
          </div>
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
            Insertion
          </div>
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-red-500" />
            Deletion
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
