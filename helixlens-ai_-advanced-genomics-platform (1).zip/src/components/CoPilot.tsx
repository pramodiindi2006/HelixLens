import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, Send, Loader2, Bot, 
  CheckCircle2, AlertCircle, Terminal
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface CoPilotProps {
  onExecute: (command: string, result: any) => void;
  expertise: 'beginner' | 'intermediate' | 'advanced';
}

export const CoPilot: React.FC<CoPilotProps> = ({ onExecute, expertise }) => {
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [history, setHistory] = useState<{ role: 'user' | 'ai', content: string }[]>([]);

  const handleSend = async () => {
    if (!input.trim() || isThinking) return;

    const userMessage = input;
    setInput('');
    setHistory(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsThinking(true);

    try {
      const resp = await fetch('/api/co-pilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: userMessage, expertise })
      });
      if (!resp.ok) {
        throw new Error('Failed to generate response');
      }
      const result = await resp.json();
      if (result.error) throw new Error(result.error);
      
      setHistory(prev => [...prev, { role: 'ai', content: result.explanation }]);
      onExecute(userMessage, result);
    } catch (error) {
      console.error("Co-Pilot Error:", error);
      const mockResult = {
        explanation: `(Simulation Mode). Strategy identified for "${userMessage}". System bypass in place.`,
        geneId: "hbb",
        mode: "knockout",
        params: { deletionSize: 1, insertionSeq: "" },
        steps: [
          "Sequence acquisition...",
          "Motif search & gRNA design...",
          "Cleavage simulation...",
          "Efficiency analysis..."
        ]
      };
      setHistory(prev => [...prev, { role: 'ai', content: mockResult.explanation }]);
      onExecute(userMessage, mockResult);
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="flex flex-col h-[450px] bg-slate-900 border border-white/10 rounded-3xl overflow-hidden shadow-2xl relative group">
      <div className="absolute inset-0 pointer-events-none z-10 border-[1px] border-white/5 opacity-30" />
      
      <div className="p-5 border-b border-white/5 bg-white/5 flex items-center justify-between backdrop-blur-md shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white text-black rounded-lg">
             <Terminal className="w-4 h-4" />
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white">Neural Assistant</span>
            <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Model: HelixLens-Cortex v4.0</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[9px] font-black text-emerald-500 uppercase tracking-tighter">Connected</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar bg-slate-900/30">
        {history.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-40">
            <div className="w-16 h-16 rounded-full border border-white/10 flex items-center justify-center animate-spin-slow">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-white">Awaiting Payload</p>
              <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest max-w-[200px]">ENTER INTERVENTION PROTOCOL OR SEQUENCE DATA COMMANDS</p>
            </div>
          </div>
        )}
        {history.map((msg, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
            animate={{ opacity: 1, x: 0 }}
            className={cn(
              "max-w-[90%] p-4 rounded-2xl text-[11px] leading-relaxed font-bold",
              msg.role === 'user' 
                ? "ml-auto bg-white text-black" 
                : "mr-auto bg-white/5 text-slate-300 border border-white/10"
            )}
          >
            <div className="flex flex-col gap-1">
               <span className="text-[8px] font-black uppercase tracking-widest opacity-40 mb-1">
                  {msg.role === 'user' ? 'Scientist' : 'Assistant'}
               </span>
               {msg.content}
            </div>
          </motion.div>
        ))}
        {isThinking && (
          <div className="flex items-center gap-3 text-slate-500 bg-white/5 border border-white/10 w-fit p-3 rounded-2xl">
            <Loader2 className="w-3 h-3 animate-spin" />
            <span className="text-[9px] font-black uppercase tracking-widest">Processing Cortical Logic...</span>
          </div>
        )}
      </div>

      <div className="p-4 bg-slate-900/60 border-t border-white/10 backdrop-blur-md">
        <div className="relative flex items-center">
          <input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="PROMPT COMMAND INTERFACE..."
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-3.5 text-[10px] font-black uppercase tracking-widest text-white focus:outline-none focus:border-white/40 transition-all placeholder:text-slate-700"
          />
          <button 
            onClick={handleSend}
            disabled={isThinking}
            className="absolute right-2 p-2.5 bg-white text-black rounded-xl hover:bg-slate-200 transition-all disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
