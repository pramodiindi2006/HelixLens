import React from 'react';
import { GeneticRiskAnalysis } from '../types/bio';
import { 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip as RechartsTooltip,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis
} from 'recharts';
import { Shield, AlertTriangle, CheckCircle2, Info, TrendingUp, Heart } from 'lucide-react';

interface RiskDashboardProps {
  analysis: GeneticRiskAnalysis;
}

export const RiskDashboard: React.FC<RiskDashboardProps> = ({ analysis }) => {
  const riskColor = analysis.overallRisk > 70 ? '#f43f5e' : analysis.overallRisk > 30 ? '#f59e0b' : '#10b981';
  
  const riskData = [
    { name: 'Risk', value: analysis.overallRisk },
    { name: 'Remaining', value: 100 - analysis.overallRisk }
  ];

  const chartData = [
    { subject: 'Family History', A: analysis.familyHistoryScore, fullMark: 100 },
    { subject: 'Inheritance', A: analysis.overallRisk > 50 ? 90 : 40, fullMark: 100 },
    { subject: 'Penetrance', A: analysis.penetranceEffect, fullMark: 100 },
    { subject: 'Carrier Prob', A: analysis.carrierProbability, fullMark: 100 },
    { subject: 'Population', A: 10, fullMark: 100 },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Risk Gauge */}
        <div className="bg-slate-800/40 border border-white/10 rounded-3xl p-8 flex flex-col items-center relative overflow-hidden group shadow-xl">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-6">Aggregated Risk Index</span>
          
          <div className="relative w-full h-44 mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={riskData}
                  cx="50%"
                  cy="80%"
                  startAngle={180}
                  endAngle={0}
                  innerRadius="70%"
                  outerRadius="95%"
                  paddingAngle={0}
                  dataKey="value"
                  stroke="none"
                >
                  <Cell fill={riskColor} className="drop-shadow-[0_0_15px_rgba(255,255,255,0.1)]" />
                  <Cell fill="rgba(255,255,255,0.05)" />
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-x-0 bottom-2 flex flex-col items-center">
              <span className="text-4xl font-black text-white tracking-tighter">{Math.round(analysis.overallRisk)}%</span>
            </div>
          </div>
          
          <div className="mt-8 pt-6 border-t border-white/5 w-full">
            <div className="flex flex-col gap-1 items-center bg-white/5 p-4 rounded-xl border border-white/10">
               <span className="text-[10px] text-slate-400 uppercase tracking-widest text-center">Confidence Score</span>
               <div className="flex items-baseline justify-center gap-1.5">
                 <span className="text-xl font-black text-emerald-400">92.4%</span>
                 <span className="text-[9px] text-slate-500 uppercase tracking-wider font-semibold">Clinical</span>
               </div>
            </div>
          </div>
        </div>

        {/* Radar Analysis */}
        <div className="bg-slate-800/40 border border-white/10 rounded-3xl p-8 col-span-1 md:col-span-2 relative overflow-hidden group shadow-xl">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-6">Variant Factor Mapping</h3>
          <div className="w-full h-56">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
                <PolarGrid stroke="rgba(255,255,255,0.05)" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 9, fontWeight: 900 }} />
                <Radar
                  name="Metrics"
                  dataKey="A"
                  stroke="white"
                  strokeWidth={2}
                  fill="white"
                  fillOpacity={0.05}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="flex items-center gap-3 border-b border-white/5 pb-4">
            <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-white" />
            </div>
            <h3 className="text-xs font-black text-white uppercase tracking-[0.2em]">Pathogenicity Findings</h3>
          </div>
          
          <div className="space-y-4">
            {analysis.findings.map((finding, idx) => (
              <div key={idx} className="p-5 bg-white/5 border border-white/10 rounded-2xl group hover:border-white/20 transition-all shadow-md">
                <div className="flex items-center justify-between mb-2.5">
                  <h4 className="text-xs font-black text-white uppercase tracking-wider">{finding.title}</h4>
                  <div className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest ${
                    finding.impact === 'High' ? 'bg-red-500 text-white shadow-[0_0_10px_rgba(239,68,68,0.3)]' : 
                    finding.impact === 'Medium' ? 'bg-amber-500 text-black' : 'bg-slate-700 text-white'
                  }`}>
                    {finding.impact}
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                  {finding.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex items-center gap-3 border-b border-white/5 pb-4">
             <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
              <Heart className="w-4 h-4 text-white" />
            </div>
            <h3 className="text-xs font-black text-white uppercase tracking-[0.2em]">Intervention Strategy</h3>
          </div>
          
          <div className="grid grid-cols-1 gap-3">
            {analysis.recommendations.map((rec, idx) => (
              <div key={idx} className="flex gap-4 p-5 bg-white/5 border border-white/10 rounded-2xl items-center group hover:bg-white/10 transition-all shadow-sm">
                <div className="w-6 h-6 rounded-full border border-white/10 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-3 h-3 text-white" />
                </div>
                <p className="text-xs text-slate-300 font-bold leading-tight">{rec}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white/5 border border-white/10 p-6 rounded-3xl flex gap-6 items-center">
        <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center shrink-0 shadow-2xl">
          <Info className="w-6 h-6 text-black" />
        </div>
        <div className="text-[11px] text-slate-300 leading-relaxed uppercase tracking-wide">
          <span className="font-black text-white block mb-1">In-Silico Research Logic</span>
          Probabilistic risk modeling based on ACMG/AMP clinical guidelines. 
          Genetic data is processed via HelixLens Bayesian engine v2.0-Alpha.
        </div>
      </div>
    </div>
  );
};
