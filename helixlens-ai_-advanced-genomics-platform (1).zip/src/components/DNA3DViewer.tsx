import React, { useMemo, useRef, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Text, Stars, Float, CameraControls, Environment, Html, Sparkles, PresentationControls, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import { motion } from 'motion/react';
import { Target, RotateCcw, Activity, Zap } from 'lucide-react';

interface DNA3DViewerProps {
  sequence: string;
  highlights?: { start: number; end: number; color: string; label?: string }[];
  cutPosition?: number | null;
  onBaseClick?: (index: number) => void;
  timelineStep?: number; // 0: Intact, 1: Binding, 2: Cutting, 3: Mutation
  mutationType?: 'knockout' | 'knockin' | 'correction' | null;
  showLabels?: boolean;
}

const BASE_COLORS: Record<string, string> = {
  A: '#10b981', // emerald-500
  T: '#f43f5e', // rose-500
  G: '#f59e0b', // amber-500
  C: '#0ea5e9', // sky-500
};

function FocusController({ targetY, timelineStep, focusTrigger }: { targetY: number; timelineStep: number; focusTrigger: number }) {
  // We can keep this empty or use it to animate OrbitControls target if needed.
  // For now, we'll just return OrbitControls to allow free movement.
  return <OrbitControls makeDefault enableDamping dampingFactor={0.05} minDistance={2} maxDistance={50} />;
}

function BasePair({ 
  index, 
  base, 
  total, 
  highlight, 
  cutPosition, 
  onClick,
  timelineStep,
  mutationType,
  showLabels = true
}: { 
  index: number; 
  base: string; 
  total: number; 
  highlight?: any; 
  cutPosition?: number | null;
  onClick?: () => void;
  timelineStep: number;
  mutationType: string | null;
  showLabels?: boolean;
}) {
  const meshRef = useRef<THREE.Group>(null);
  const base1Ref = useRef<THREE.Mesh>(null);
  const base2Ref = useRef<THREE.Mesh>(null);
  const connectorRef = useRef<THREE.Mesh>(null);
  
  const [hovered, setHovered] = useState(false);
  const currentScale = useRef(1);

  const radius = 2;
  const heightStep = 0.5;
  const rotationStep = 0.4;

  const targetY = (index - total / 2) * heightStep;
  const angle = index * rotationStep;

  const x1 = Math.cos(angle) * radius;
  const z1 = Math.sin(angle) * radius;
  const x2 = Math.cos(angle + Math.PI) * radius;
  const z2 = Math.sin(angle + Math.PI) * radius;

  const currentY = useRef(targetY);
  const currentYOffset = useRef(0);
  const currentShake = useRef(0);
  const currentFlash = useRef(0);

  const color = highlight ? highlight.color.replace('border-', '#') : BASE_COLORS[base] || '#555555';
  const complementaryBase = base === 'A' ? 'T' : base === 'T' ? 'A' : base === 'G' ? 'C' : base === 'C' ? 'G' : '-';
  const compColor = BASE_COLORS[complementaryBase] || '#555555';

  // Animation logic for cutting and joining
  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Interactive hover physics (spring-like scale)
    let targetScale = hovered ? 1.15 : 1;
    
    // Deletion / Replacement animation in phase 3
    if (timelineStep >= 3) {
      if (mutationType === 'knockout') {
        // In a knockout, typically we delete bases right AT the cut site.
        if (cutPosition !== null && index >= cutPosition && index < cutPosition + 1) {
          targetScale = 0; // fade out the deleted base!
        }
      } else if (mutationType === 'correction' || mutationType === 'knockin') {
        // Fade out replaced bases to make room for HDR template
        if (cutPosition !== null && index >= cutPosition - 2 && index <= cutPosition + 2) {
          targetScale = 0.1; // Shrink significantly or mostly hide
        }
      }
    }

    currentScale.current = THREE.MathUtils.lerp(currentScale.current, targetScale, delta * 10);
    meshRef.current.scale.setScalar(currentScale.current);

    // Smoothly interpolate the base Y position (handles sequence length changes)
    const ySpeed = timelineStep === 3 ? 1.5 : 3;
    currentY.current = THREE.MathUtils.lerp(currentY.current, targetY, delta * ySpeed);

    let targetYOffset = 0;
    let targetShake = 0;

    if (cutPosition !== null && timelineStep === 2) {
      // Cut phase: separate the two halves vertically
      const separationDistance = 2.5;
      if (index > cutPosition) {
        targetYOffset = separationDistance;
      } else {
        targetYOffset = -separationDistance;
      }
      
      // Shake bases near the cut
      if (Math.abs(index - cutPosition) <= 2) {
         targetShake = 0.05;
      }
    } else if (timelineStep === 3) {
      // Joining phase: bring them back together
      targetYOffset = 0;
      if (mutationType === 'knockout' && Math.abs(index - (cutPosition || 0)) <= 1) {
         // Indel scar glitch
         targetShake = 0.03;
      } else {
         targetShake = 0;
      }
    }

    // Smoothly interpolate the Y offset (slower for clarity and smooth joining)
    const offsetSpeed = timelineStep === 3 ? 1.5 : 4;
    currentYOffset.current = THREE.MathUtils.lerp(currentYOffset.current, targetYOffset, delta * offsetSpeed);
    
    // Apply shake
    const t = state.clock.getElapsedTime();
    if (targetShake > 0) {
       currentShake.current = THREE.MathUtils.lerp(currentShake.current, Math.sin(t * 40 + index) * targetShake, delta * 15);
    } else {
       currentShake.current = THREE.MathUtils.lerp(currentShake.current, 0, delta * 10);
    }

    meshRef.current.position.y = currentY.current + currentYOffset.current;
    meshRef.current.position.x = currentShake.current;
    
    // Flash effect on the exact cut position
    if (index === cutPosition && connectorRef.current) {
       const material = connectorRef.current.material as THREE.MeshStandardMaterial;
       if (timelineStep === 2) {
          // High intensity flash when cut is active
          currentFlash.current = THREE.MathUtils.lerp(currentFlash.current, 8, delta * 5);
          material.emissiveIntensity = currentFlash.current;
          material.color.setHex(0xffffff);
          material.emissive.setHex(0xffffff);
       } else if (timelineStep === 3) {
          if (mutationType === 'knockout') {
             // Red glow for NHEJ error scar
             currentFlash.current = THREE.MathUtils.lerp(currentFlash.current, 4, delta * 2);
             material.emissiveIntensity = currentFlash.current;
             material.color.setHex(0xef4444); // red-500
             material.emissive.setHex(0xef4444);
          } else {
             // Green glow for successful HDR repair
             currentFlash.current = THREE.MathUtils.lerp(currentFlash.current, 4, delta * 2);
             material.emissiveIntensity = currentFlash.current;
             material.color.setHex(0x10b981); // emerald-500
             material.emissive.setHex(0x10b981);
          }
       } else {
          // Persistent red glow for predicted cut site
          currentFlash.current = THREE.MathUtils.lerp(currentFlash.current, 3, delta * 5);
          material.emissiveIntensity = currentFlash.current;
          material.color.setHex(0xef4444); // red-500
          material.emissive.setHex(0xef4444);
       }
    }
  });

  return (
    <group 
      ref={meshRef} 
      position={[0, targetY, 0]} 
      onClick={(e) => { e.stopPropagation(); onClick?.(); }}
      onPointerOver={(e) => { e.stopPropagation(); setHovered(true); document.body.style.cursor = 'pointer'; }}
      onPointerOut={(e) => { e.stopPropagation(); setHovered(false); document.body.style.cursor = 'auto'; }}
    >
      {/* Backbone 1 */}
      <mesh position={[x1, 0, z1]}>
        <sphereGeometry args={[0.25, 32, 32]} />
        <meshPhysicalMaterial color="#334155" metalness={0.5} roughness={0.4} clearcoat={1} clearcoatRoughness={0.2} />
      </mesh>
      {showLabels && (
        <Text
          position={[x1 * 0.8, 0.4, z1 * 0.8]}
          rotation={[0, -angle + Math.PI/2, 0]}
          fontSize={0.4}
          color="#ffffff">
          {base}
        </Text>
      )}

      {/* Backbone 2 */}
      <mesh position={[x2, 0, z2]}>
        <sphereGeometry args={[0.25, 32, 32]} />
        <meshPhysicalMaterial color="#334155" metalness={0.5} roughness={0.4} clearcoat={1} clearcoatRoughness={0.2} />
      </mesh>
      {showLabels && (
        <Text
          position={[x2 * 0.8, 0.4, z2 * 0.8]}
          rotation={[0, -angle - Math.PI/2, 0]}
          fontSize={0.4}
          color="#ffffff">
          {complementaryBase}
        </Text>
      )}

      {/* Connector (Hydrogen Bond) */}
      <mesh ref={connectorRef} position={[0, 0, 0]} rotation={[0, -angle, 0]}>
        <boxGeometry args={[1.4, 0.05, 0.05]} />
        <meshPhysicalMaterial 
          color={index === cutPosition ? "#ef4444" : (highlight ? color : "#ffffff")} 
          emissive={index === cutPosition ? "#ef4444" : (highlight ? color : "#000000")}
          emissiveIntensity={index === cutPosition ? 3 : (highlight ? 2 : 0)}
          transparent 
          opacity={index === cutPosition ? 0.8 : 0.3} 
          roughness={0.2}
          transmission={0.5}
        />
      </mesh>

      {/* Base 1 */}
      <RoundedBox ref={base1Ref} args={[1.2, 0.25, 0.4]} radius={0.05} smoothness={4} position={[x1 * 0.65, 0, z1 * 0.65]} rotation={[0, -angle, 0]}>
        <meshPhysicalMaterial 
          color={color} 
          emissive={color}
          emissiveIntensity={highlight ? 0.8 : 0.2}
          roughness={0.2}
          metalness={0.1}
          clearcoat={0.8}
        />
        <Text
          position={[0, 0.16, 0]}
          rotation={[-Math.PI / 2, 0, Math.PI / 2]}
          fontSize={0.25}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
          fontWeight="bold"
        >
          {base}
        </Text>
      </RoundedBox>

      {/* Base 2 */}
      <RoundedBox ref={base2Ref} args={[1.2, 0.25, 0.4]} radius={0.05} smoothness={4} position={[x2 * 0.65, 0, z2 * 0.65]} rotation={[0, -angle, 0]}>
        <meshPhysicalMaterial 
          color={compColor} 
          emissive={compColor}
          emissiveIntensity={0.1}
          opacity={0.9} 
          transparent 
          roughness={0.2} 
          metalness={0.1} 
          clearcoat={0.8} 
        />
        <Text
          position={[0, 0.16, 0]}
          rotation={[-Math.PI / 2, 0, -Math.PI / 2]}
          fontSize={0.25}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
          fontWeight="bold"
        >
          {complementaryBase}
        </Text>
      </RoundedBox>

      {/* Label if highlighted */}
      {showLabels && highlight && (
        <Html position={[x1 * 1.5, 0, z1 * 1.5]} center distanceFactor={15} zIndexRange={[100, 0]}>
          <div className={`px-1.5 py-0.5 rounded border text-[8px] whitespace-nowrap font-bold uppercase backdrop-blur-sm pointer-events-none text-center
            ${highlight.label.includes('HDR') ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400' : 
              highlight.label.includes('NHEJ') ? 'bg-red-500/20 border-red-500/50 text-red-400' :
              highlight.label.includes('PAM') ? 'bg-amber-500/20 border-amber-500/50 text-amber-400' :
              highlight.label.includes('gRNA') ? 'bg-purple-500/20 border-purple-500/50 text-purple-400' :
              'bg-slate-800/80 border-slate-700 text-slate-300'
            }`}
          >
            {highlight.label}
          </div>
        </Html>
      )}

      {/* Predicted Cut Site Label */}
      {showLabels && index === cutPosition && !highlight?.label?.includes('HDR') && !highlight?.label?.includes('NHEJ') && (
        <Html position={[x1 * 1.5, 0, z1 * 1.5]} center distanceFactor={15} zIndexRange={[100, 0]}>
          <div className={`flex items-center gap-1 backdrop-blur-md text-[8px] px-2 py-1 rounded border whitespace-nowrap font-bold uppercase tracking-wider pointer-events-none ${timelineStep === 3 ? (mutationType === 'knockout' ? 'bg-red-500/20 text-red-500 border-red-500/50' : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50') : 'bg-red-500/20 text-red-400 border-red-500/50'}`}>
            <div className={`w-1 h-4 animate-pulse rounded-full ${timelineStep === 3 ? (mutationType === 'knockout' ? 'bg-red-500' : 'bg-emerald-500') : 'bg-red-500'}`} />
            {timelineStep === 3 ? (mutationType === 'knockout' ? 'NHEJ Repair – Mutation Introduced' : 'HDR Repair – Precise Edit') : (timelineStep === 2 ? 'Double-Strand Break (DSB)' : 'Target Sequence')}
          </div>
        </Html>
      )}
    </group>
  );
}

function Cas9Model({ targetIndex, total, timelineStep, showLabels }: { targetIndex: number; total: number; timelineStep: number; showLabels: boolean }) {
  const groupRef = useRef<THREE.Group>(null);
  const bodyMaterialRef = useRef<THREE.MeshPhysicalMaterial>(null);
  const gRNARef = useRef<THREE.Mesh>(null);
  
  const heightStep = 0.5;
  const targetY = (targetIndex - total / 2) * heightStep;
  
  const active = timelineStep >= 1;

  useFrame((state, delta) => {
    if (groupRef.current) {
      const t = state.clock.getElapsedTime();
      
      // Base target position - align exactly with DNA
      const targetPos = active ? new THREE.Vector3(0, targetY, 0) : new THREE.Vector3(15, targetY + 15, 15);
      
      // Simulate 3D diffusion / 1D sliding scanning mechanism
      if (timelineStep === 1) {
         if (t % 3 < 1.5) { 
            // 1D sliding along DNA backbone
            targetPos.y += Math.sin(t * 8) * 1.5;
            targetPos.z += Math.cos(t * 15) * 0.2; // slight spiral
         } else {
            // 3D finding
            targetPos.x += Math.sin(t * 4) * 0.5;
         }
      }
      
      // Explicit animations based on timelineStep
      if (timelineStep === 1) {
        // Scanning: Open conformation
        groupRef.current.scale.lerp(new THREE.Vector3(1.1, 1.1, 1.1), delta * 4);
        groupRef.current.position.lerp(targetPos, delta * 4);
      } else if (timelineStep === 2) {
        // Cleavage: Closed active conformation, clamped tight
        groupRef.current.scale.lerp(new THREE.Vector3(0.8, 0.9, 0.8), delta * 8);
        groupRef.current.position.lerp(targetPos, delta * 10);
      } else {
        // Inactive / Release
        groupRef.current.scale.lerp(new THREE.Vector3(1, 1, 1), delta * 5);
        groupRef.current.position.lerp(targetPos, delta * 5);
      }
      
      // Global spin for effect
      if (timelineStep === 2) {
        groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, Math.PI, delta * 2);
      } else if (active) {
        groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, 0, delta * 2);
      }

      // Emissive glow on Cas9 body based on phase
      if (bodyMaterialRef.current) {
        let targetEmissive = 0.1;
        if (timelineStep === 1) targetEmissive = 0.3; // Binding glow
        else if (timelineStep === 2) targetEmissive = 1.0; // Cleavage bright glow
        else if (timelineStep === 3) targetEmissive = 0.1; // Post-cleavage
        
        bodyMaterialRef.current.emissiveIntensity = THREE.MathUtils.lerp(bodyMaterialRef.current.emissiveIntensity, targetEmissive, delta * 5);
      }

      // gRNA pulse
      if (gRNARef.current) {
        const pulse = timelineStep === 1 ? 1 + Math.sin(t * 8) * 0.1 : 1;
        gRNARef.current.scale.lerp(new THREE.Vector3(pulse, pulse, pulse), delta * 5);
      }
    }
  });

  return (
    <group ref={groupRef} position={[15, targetY + 15, 15]}>
      {/* Cas9 Protein - Unified Body */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        {/* A thick torus represents the bi-lobed structure wrapping the DNA */}
        <torusGeometry args={[2.5, 1.2, 32, 64, Math.PI * 1.5]} />
        <meshPhysicalMaterial 
          ref={bodyMaterialRef}
          color="#a855f7" 
          emissive="#7e22ce" 
          emissiveIntensity={0.1} 
          transmission={0.4} 
          opacity={0.85} 
          transparent 
          metalness={0.1} 
          roughness={0.4} 
          ior={1.3} 
        />
        {showLabels && active && (
           <Html position={[-3, 2, 0]} center>
             <div className="bg-slate-900/80 backdrop-blur-md text-purple-300 text-[9px] px-2 py-1 rounded border border-purple-500/30 whitespace-nowrap font-mono">
               Cas9 Endonuclease
             </div>
           </Html>
        )}
      </mesh>
      
      {/* sgRNA Molecule (Single Guide RNA) */}
      <group position={[0, 0, 0]}>
        <mesh ref={gRNARef} rotation={[Math.PI / 4, 0, 0]}>
          {/* Complex tubing to represent secondary structure of RNA inside the Cas9 */}
          <tubeGeometry args={[new THREE.CatmullRomCurve3([
            new THREE.Vector3(0, -2, 0),
            new THREE.Vector3(1, -1, 1),
            new THREE.Vector3(0, 0, 1.5),
            new THREE.Vector3(-1, 1, 1),
            new THREE.Vector3(0, 2, 0)
          ]), 64, 0.15, 8, false]} />
          <meshPhysicalMaterial color="#2dd4bf" emissive="#0f766e" emissiveIntensity={1} roughness={0.1} metalness={0.8} />
        </mesh>
        
        {showLabels && active && (
          <Html position={[0, -2.5, 0]} center>
            <div className="bg-slate-900/80 backdrop-blur-md text-teal-300 text-[9px] px-2 py-1 rounded border border-teal-500/30 whitespace-nowrap font-mono flex flex-col items-center">
              <span>sgRNA</span>
            </div>
          </Html>
        )}
      </group>

      {/* Domain Labels mapping on the unified structure */}
      {showLabels && active && (
         <group>
            {/* HNH / RuvC Target Sites represented by distinct glowing nodes within the main body */}
            <mesh position={[-1.2, 0.5, 1.5]}>
               <sphereGeometry args={[0.5, 16, 16]} />
               <meshPhysicalMaterial color="#ec4899" emissive="#be185d" emissiveIntensity={timelineStep === 2 ? 2 : 0.2} transparent opacity={0.6}/>
               <Html position={[-1, 0.5, 2]} center>
                 <div className="bg-slate-900/80 backdrop-blur-md text-pink-300 text-[8px] px-1 py-0.5 rounded border border-pink-500/30 whitespace-nowrap font-mono flex gap-1 items-center">
                   {timelineStep === 2 && <span className="w-1 h-3 bg-pink-500 animate-bounce" />}
                   HNH
                 </div>
               </Html>
            </mesh>
            <mesh position={[1.2, 1.5, -1]}>
               <sphereGeometry args={[0.5, 16, 16]} />
               <meshPhysicalMaterial color="#3b82f6" emissive="#1d4ed8" emissiveIntensity={timelineStep === 2 ? 2 : 0.2} transparent opacity={0.6} />
               <Html position={[2, 2, -1.5]} center>
                 <div className="bg-slate-900/80 backdrop-blur-md text-blue-300 text-[8px] px-1 py-0.5 rounded border border-blue-500/30 whitespace-nowrap font-mono flex gap-1 items-center">
                   {timelineStep === 2 && <span className="w-1 h-3 bg-blue-500 animate-bounce" />}
                   RuvC
                 </div>
               </Html>
            </mesh>
         </group>
      )}

      {showLabels && active && (
        <Html position={[0, 6, 0]} center distanceFactor={15} zIndexRange={[100, 0]}>
          <div className="bg-slate-900/95 backdrop-blur-xl text-white text-[10px] p-3 rounded-xl border border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.3)] pointer-events-none min-w-[200px]">
            <div className="flex justify-between border-b border-slate-700 pb-1 mb-2">
              <span className="font-black text-purple-400 tracking-wider">CRISPR-Cas9 Complex</span>
              <span className={`font-mono ${timelineStep === 1 ? 'text-amber-400 animate-pulse' : timelineStep === 2 ? 'text-red-400' : 'text-emerald-400'}`}>
                {timelineStep === 1 ? 'SEARCHING' : timelineStep === 2 ? 'ACTIVE' : 'COMPLETE'}
              </span>
            </div>
            <div className="space-y-1 text-[9px] font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">PAM Interaction:</span>
                <span className={timelineStep >= 2 ? 'text-emerald-400' : 'text-amber-400'}>{timelineStep >= 2 ? 'Locked (NGG)' : 'Scanning...'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">gRNA Hybridization:</span>
                <span className={timelineStep >= 2 ? 'text-emerald-400' : 'text-amber-400'}>{timelineStep >= 2 ? 'Complete' : 'Base pairing...'}</span>
              </div>
              <div className="flex justify-between mt-1 pt-1 border-t border-slate-800">
                <span className="text-slate-400">HNH State:</span>
                <span className={timelineStep === 2 ? 'text-pink-400 font-bold' : 'text-slate-500'}>{timelineStep === 2 ? 'CLEAVING TARGET' : 'Inactive'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">RuvC State:</span>
                <span className={timelineStep === 2 ? 'text-blue-400 font-bold' : 'text-slate-500'}>{timelineStep === 2 ? 'CLEAVING NON-TARGET' : 'Inactive'}</span>
              </div>
            </div>
          </div>
        </Html>
      )}
    </group>
  );
}

function Shockwave({ active, position }: { active: boolean; position: [number, number, number] }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<THREE.MeshBasicMaterial>(null);

  useFrame((state, delta) => {
    if (!meshRef.current || !materialRef.current) return;
    
    if (active) {
      meshRef.current.visible = true;
      meshRef.current.scale.addScalar(delta * 15);
      materialRef.current.opacity = Math.max(0, materialRef.current.opacity - delta * 2);
    } else {
      meshRef.current.scale.setScalar(0.1);
      materialRef.current.opacity = 0.8;
      meshRef.current.visible = false;
    }
  });

  return (
    <mesh ref={meshRef} position={position} rotation={[Math.PI / 2, 0, 0]}>
      <ringGeometry args={[0.9, 1, 32]} />
      <meshBasicMaterial ref={materialRef} color="#ffffff" transparent opacity={0.8} side={THREE.DoubleSide} />
    </mesh>
  );
}

function HDRTemplate({ active, cutY, mutationType, showLabels }: { active: boolean; cutY: number; mutationType: string | null; showLabels: boolean }) {
  const groupRef = useRef<THREE.Group>(null);
  
  useFrame((state, delta) => {
    if (!groupRef.current) return;
    
    // Only show HDR template for Knock-in or Correction
    if (active && mutationType && mutationType !== 'knockout') {
      groupRef.current.position.lerp(new THREE.Vector3(0, cutY, 0), delta * 2);
      groupRef.current.visible = true;
    } else {
      groupRef.current.position.lerp(new THREE.Vector3(15, cutY + 5, -10), delta * 4);
      if (groupRef.current.position.x > 14) {
        groupRef.current.visible = false;
      }
    }
  });

  // Render a snippet of 5 base pairs for the template
  const templateBases = ["A", "T", "C", "G", "A"];
  const heightStep = 0.5;

  return (
    <group ref={groupRef} rotation={[0, 0, 0]}>
      <group position={[0, -templateBases.length/2 * heightStep, 0]}>
         {templateBases.map((base, i) => {
            const angle = i * 0.4;
            const x1 = Math.cos(angle) * 2;
            const z1 = Math.sin(angle) * 2;
            const x2 = Math.cos(angle + Math.PI) * 2;
            const z2 = Math.sin(angle + Math.PI) * 2;
            const color = BASE_COLORS[base] || "#fff";
            const compBase = base === 'A' ? 'T' : base === 'T' ? 'A' : base === 'G' ? 'C' : base === 'C' ? 'G' : '-';
            const compColor = BASE_COLORS[compBase] || "#fff";
            
            return (
              <group key={i} position={[0, i * heightStep, 0]}>
                 <mesh position={[0, 0, 0]} rotation={[0, -angle, 0]}>
                   <boxGeometry args={[1.4, 0.05, 0.05]} />
                   <meshPhysicalMaterial color="#34d399" emissive="#059669" emissiveIntensity={2} transparent opacity={0.8} />
                 </mesh>
                 {/* Bases */}
                 <RoundedBox args={[1.2, 0.25, 0.4]} radius={0.05} position={[x1 * 0.65, 0, z1 * 0.65]} rotation={[0, -angle, 0]}>
                    <meshPhysicalMaterial color={color} emissive={color} emissiveIntensity={0.5} opacity={0.6} transparent />
                 </RoundedBox>
                 {showLabels && (
                   <Text
                     position={[x1 * 0.65, 0.4, z1 * 0.65]}
                     rotation={[0, -angle + Math.PI/2, 0]}
                     fontSize={0.4}
                     color="#ffffff">
                     {base}
                   </Text>
                 )}
                 <RoundedBox args={[1.2, 0.25, 0.4]} radius={0.05} position={[x2 * 0.65, 0, z2 * 0.65]} rotation={[0, -angle, 0]}>
                    <meshPhysicalMaterial color={compColor} emissive={compColor} emissiveIntensity={0.5} opacity={0.6} transparent />
                 </RoundedBox>
                 {showLabels && (
                   <Text
                     position={[x2 * 0.65, 0.4, z2 * 0.65]}
                     rotation={[0, -angle - Math.PI/2, 0]}
                     fontSize={0.4}
                     color="#ffffff">
                     {compBase}
                   </Text>
                 )}
              </group>
            );
         })}
      </group>
      {showLabels && (
        <Html position={[2, 0, 0]} center distanceFactor={15}>
          <div className="bg-emerald-500/20 backdrop-blur-md text-emerald-400 text-[8px] px-2 py-1 rounded border border-emerald-500/50 pointer-events-none tracking-widest font-bold uppercase transition-all">
            Donor Template
          </div>
        </Html>
      )}
    </group>
  );
}

export function DNA3DViewer({ sequence, highlights = [], cutPosition, onBaseClick, timelineStep = 0, mutationType = null, showLabels = true }: DNA3DViewerProps) {
  // Use fallback to avoid .length errors if sequence is undefined
  const seq = sequence || '';
  
  // Limit the sequence length rendered in 3D to avoid WebGL context loss on large sequences
  const MAX_RENDER_BASES = 120;
  let renderStart = 0;
  let renderEnd = seq.length;

  if (seq.length > MAX_RENDER_BASES) {
    if (cutPosition !== null && cutPosition !== undefined) {
      renderStart = Math.max(0, cutPosition - Math.floor(MAX_RENDER_BASES / 2));
      renderEnd = Math.min(seq.length, renderStart + MAX_RENDER_BASES);
      if (renderEnd - renderStart < MAX_RENDER_BASES) {
        renderStart = Math.max(0, renderEnd - MAX_RENDER_BASES);
      }
    } else {
      renderEnd = Math.min(seq.length, MAX_RENDER_BASES);
    }
  }

  const renderSequence = seq.slice(renderStart, renderEnd);
  
  // Adjust cut position and highlights to the windowed sequence
  const relativeCutPosition = cutPosition !== null && cutPosition !== undefined 
    ? cutPosition - renderStart 
    : null;
    
  const relativeHighlights = highlights.map(h => ({
    ...h,
    start: h.start - renderStart,
    end: h.end - renderStart
  })).filter(h => h.end > 0 && h.start < renderSequence.length);

  const targetIndex = relativeCutPosition !== null ? relativeCutPosition - 8 : (relativeHighlights.find(h => h.label === 'gRNA Target')?.start || 0);
  const heightStep = 0.5;
  const targetY = (targetIndex - renderSequence.length / 2) * heightStep;
  const cutY = relativeCutPosition !== null ? (relativeCutPosition - renderSequence.length / 2) * heightStep : 0;
  const [focusTrigger, setFocusTrigger] = useState(0);

  return (
    <div className="w-full h-[500px] bg-slate-900 rounded-3xl overflow-hidden relative border border-slate-800 shadow-2xl group">
      {/* Structural Decoration - Technical HUD Lines */}
      <div className="absolute inset-0 pointer-events-none z-10 border-[20px] border-transparent">
        <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-slate-700/50" />
        <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-slate-700/50" />
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-slate-700/50" />
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-slate-700/50" />
      </div>

      <Canvas shadows dpr={[1, 2]}>
        <fog attach="fog" args={['#0f172a', 15, 45]} />
        <Environment preset="studio" />
        <PerspectiveCamera makeDefault position={[12, 0, 12]} fov={40} />
        <FocusController targetY={targetY} timelineStep={timelineStep} focusTrigger={focusTrigger} />
        
        <ambientLight intensity={0.4} />
        <pointLight position={[10, 10, 10]} intensity={1.5} />
        <spotLight position={[-15, 20, 10]} angle={0.2} penumbra={1} intensity={2} castShadow />
        
        <Stars radius={100} depth={50} count={2000} factor={4} saturation={0} fade speed={0.5} />
        <Sparkles count={150} scale={25} size={1.5} speed={0.3} opacity={0.2} color="#ffffff" />

        <group rotation={[0, 0, 0]}>
          <Float speed={1.2} rotationIntensity={0.1} floatIntensity={0.3}>
            {/* 5' / 3' Markers Top */}
            {showLabels && (
              <group position={[0, -renderSequence.length/2 * heightStep - 1, 0]}>
                <Html position={[2.5, 0, 2.5]} center>
                  <div className="text-[9px] font-black tracking-widest text-slate-600 whitespace-nowrap uppercase">TERMINUS 5&apos;</div>
                </Html>
              </group>
            )}
            
            {renderSequence.split('').map((base, i) => (
              <BasePair
                key={i}
                index={i}
                base={base}
                total={renderSequence.length}
                highlight={relativeHighlights.find(h => i >= h.start && i < h.end)}
                cutPosition={relativeCutPosition}
                onClick={() => onBaseClick?.(i + renderStart)}
                timelineStep={timelineStep}
                mutationType={mutationType}
                showLabels={showLabels}
              />
            ))}
            
            {/* 5' / 3' Markers Bottom */}
            {showLabels && (
              <group position={[0, renderSequence.length/2 * heightStep + 1, 0]}>
                <Html position={[-2.5, 0, -2.5]} center>
                  <div className="text-[9px] font-black tracking-widest text-slate-600 whitespace-nowrap uppercase">TERMINUS 3&apos;</div>
                </Html>
              </group>
            )}
          </Float>
          
          <Cas9Model 
            targetIndex={targetIndex} 
            total={renderSequence.length} 
            timelineStep={timelineStep} 
            showLabels={showLabels}
          />
          
          <HDRTemplate 
            active={timelineStep === 2 || timelineStep === 3} 
            cutY={cutY} 
            mutationType={mutationType} 
            showLabels={showLabels}
          />
          
          <Shockwave active={timelineStep === 2} position={[0, cutY, 0]} />
        </group>
      </Canvas>

      {/* Interactive HUD Elements */}
      <div className="absolute top-8 left-8 z-20 pointer-events-none">
        <div className="flex flex-col gap-1">
          <span className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em]">Scanner v4.2</span>
          <div className="h-0.5 w-12 bg-white/20" />
        </div>
      </div>

      <div className="absolute top-8 right-8 flex flex-col gap-3 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-x-4 group-hover:translate-x-0">
        <button 
          onClick={() => setFocusTrigger(prev => prev + 1)}
          className="w-10 h-10 bg-white/5 backdrop-blur-xl border border-white/10 rounded-full flex items-center justify-center text-white hover:bg-white/10 transition-all pointer-events-auto"
          title="Focus Target"
        >
          <Target className="w-4 h-4" />
        </button>
        <button 
          onClick={() => setFocusTrigger(0)}
          className="w-10 h-10 bg-white/5 backdrop-blur-xl border border-white/10 rounded-full flex items-center justify-center text-white hover:bg-white/10 transition-all pointer-events-auto"
          title="Reset View"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      <div className="absolute bottom-8 left-8 right-8 flex justify-between items-end pointer-events-none z-20">
        <div className="flex flex-col gap-2">
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 px-4 py-2 rounded-xl text-[9px] font-black text-white uppercase tracking-widest pointer-events-auto flex items-center gap-3">
            <Activity className="w-3 h-3 text-emerald-400 animate-pulse" />
            REAL-TIME MOLECULAR RENDER
          </div>
        </div>
        
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 px-4 py-2 rounded-xl pointer-events-auto">
          <div className="flex items-center gap-4 text-[9px] font-black uppercase tracking-[0.1em]">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-[#10b981]" />
              <span className="text-slate-400">A</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-[#f43f5e]" />
              <span className="text-slate-400">T</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-[#f59e0b]" />
              <span className="text-slate-400">G</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-[#0ea5e9]" />
              <span className="text-slate-400">C</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
