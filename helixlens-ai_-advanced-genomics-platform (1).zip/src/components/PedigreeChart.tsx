import React from 'react';
import { FamilyMember } from '../types/bio';
import { motion } from 'motion/react';
import { User, Users, AlertCircle } from 'lucide-react';

interface PedigreeChartProps {
  members: FamilyMember[];
  onMemberClick?: (member: FamilyMember) => void;
}

export const PedigreeChart: React.FC<PedigreeChartProps> = ({ members, onMemberClick }) => {
  // Simple layout logic for a 3-generation tree
  const getPosition = (member: FamilyMember) => {
    switch (member.relation) {
      case 'Paternal Grandfather': return { x: 50, y: 50 };
      case 'Paternal Grandmother': return { x: 150, y: 50 };
      case 'Maternal Grandfather': return { x: 250, y: 50 };
      case 'Maternal Grandmother': return { x: 350, y: 50 };
      case 'Father': return { x: 100, y: 150 };
      case 'Mother': return { x: 300, y: 150 };
      case 'Self': return { x: 200, y: 250 };
      case 'Sibling': return { x: 250, y: 250 };
      default: return { x: 0, y: 0 };
    }
  };

  const renderShape = (member: FamilyMember) => {
    const { x, y } = getPosition(member);
    const size = 32;
    const isMale = member.sex === 'M';
    
    return (
      <g 
        key={member.id} 
        className="cursor-pointer group"
        onClick={() => onMemberClick?.(member)}
      >
        <motion.rect
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: 'spring', damping: 20 }}
          x={x - size / 2}
          y={y - size / 2}
          width={size}
          height={size}
          rx={isMale ? 4 : 16}
          className={`
            ${member.affected ? 'fill-black stroke-white stroke-[3px]' : member.carrier ? 'fill-white/20 stroke-white/40 shadow-lg' : 'fill-slate-800/60 stroke-white/10'}
            transition-all duration-300 group-hover:stroke-white group-hover:scale-110
          `}
        />
        {member.relation === 'Self' && (
          <path 
            d={`M ${x} ${y + size/2 + 2} L ${x - 4} ${y + size/2 + 10} L ${x + 4} ${y + size/2 + 10} Z`}
            className="fill-white animate-bounce"
          />
        )}
        <text 
          x={x} 
          y={y + size/2 + 25} 
          textAnchor="middle" 
          className="text-[9px] fill-slate-500 font-black uppercase tracking-widest select-none"
        >
          {member.relation}
        </text>
      </g>
    );
  };

  return (
    <div className="w-full aspect-video bg-slate-900 rounded-3xl border border-white/10 p-8 relative overflow-hidden group shadow-2xl">
      <div className="absolute inset-0 bg-slate-900/20" />
      
      {/* HUD Accents */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-20">
         <div className="absolute top-10 left-10 w-24 h-[1px] bg-white" />
         <div className="absolute top-10 left-10 w-[1px] h-24 bg-white" />
      </div>

      <div className="absolute top-8 left-8 flex items-center gap-4 z-10">
        <div className="p-2 bg-white text-black rounded-lg">
          <Users className="w-5 h-5" />
        </div>
        <div className="flex flex-col">
          <h3 className="text-sm font-black text-white uppercase tracking-[0.2em]">Kinship Distribution</h3>
          <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Pedigree v1.8 - Clinical Mapping</span>
        </div>
      </div>
      
      <svg viewBox="0 0 400 320" className="w-full h-full relative z-10">
        {/* Connection Lines (Static for this layout) */}
        <g className="stroke-white/10 stroke-[2px] fill-none">
          {/* Grandparents to Parents */}
          <path d="M 50 65 L 150 65 M 100 65 L 100 150" />
          <path d="M 250 65 L 350 65 M 300 65 L 300 150" />
          {/* Parents to Children */}
          <path d="M 100 165 L 300 165" />
          <path d="M 200 165 L 200 250" />
          <path d="M 200 200 L 250 200 L 250 250" />
        </g>
        
        {members.map(member => renderShape(member))}
      </svg>

      <div className="absolute bottom-8 left-8 flex flex-wrap gap-6 text-[9px] font-black uppercase tracking-widest z-10 bg-black/40 backdrop-blur-xl p-3 border border-white/5 rounded-2xl">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-white rounded-sm" />
          <span className="text-white">Affected</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 border border-white/40 rounded-sm" />
          <span className="text-slate-500">Carrier</span>
        </div>
        <div className="flex items-center gap-2 text-slate-400">
           <div className="w-3 h-3 bg-slate-800 border border-white/10 rounded-sm" />
           <span>Male</span>
        </div>
        <div className="flex items-center gap-2 text-slate-400">
           <div className="w-3 h-3 bg-slate-800 border border-white/10 rounded-full" />
           <span>Female</span>
        </div>
      </div>
    </div>
  );
};
