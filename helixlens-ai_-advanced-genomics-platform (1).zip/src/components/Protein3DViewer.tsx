import React, { useMemo, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Stars, Float, Text, Environment, Sparkles, Html } from '@react-three/drei';
import * as THREE from 'three';

interface Protein3DViewerProps {
  protein: string;
  diffs?: { char1?: string; char2?: string; type: 'match' | 'mismatch' | 'insertion' | 'deletion' | 'frameshift' }[];
}

const AMINO_ACID_COLORS: Record<string, string> = {
  'match': '#10b981',
  'mismatch': '#f59e0b',
  'insertion': '#3b82f6',
  'deletion': '#f43f5e',
  'frameshift': '#a855f7',
};

const AMINO_ACID_PROPERTIES: Record<string, { name: string; type: string; polarity: string; charge: string }> = {
  'A': { name: 'Alanine', type: 'Aliphatic', polarity: 'Nonpolar', charge: 'Neutral' },
  'R': { name: 'Arginine', type: 'Basic', polarity: 'Polar', charge: 'Positive' },
  'N': { name: 'Asparagine', type: 'Amide', polarity: 'Polar', charge: 'Neutral' },
  'D': { name: 'Aspartic Acid', type: 'Acidic', polarity: 'Polar', charge: 'Negative' },
  'C': { name: 'Cysteine', type: 'Sulfur-containing', polarity: 'Nonpolar', charge: 'Neutral' },
  'E': { name: 'Glutamic Acid', type: 'Acidic', polarity: 'Polar', charge: 'Negative' },
  'Q': { name: 'Glutamine', type: 'Amide', polarity: 'Polar', charge: 'Neutral' },
  'G': { name: 'Glycine', type: 'Aliphatic', polarity: 'Nonpolar', charge: 'Neutral' },
  'H': { name: 'Histidine', type: 'Basic', polarity: 'Polar', charge: 'Positive (pH < 6)' },
  'I': { name: 'Isoleucine', type: 'Aliphatic', polarity: 'Nonpolar', charge: 'Neutral' },
  'L': { name: 'Leucine', type: 'Aliphatic', polarity: 'Nonpolar', charge: 'Neutral' },
  'K': { name: 'Lysine', type: 'Basic', polarity: 'Polar', charge: 'Positive' },
  'M': { name: 'Methionine', type: 'Sulfur-containing', polarity: 'Nonpolar', charge: 'Neutral' },
  'F': { name: 'Phenylalanine', type: 'Aromatic', polarity: 'Nonpolar', charge: 'Neutral' },
  'P': { name: 'Proline', type: 'Cyclic', polarity: 'Nonpolar', charge: 'Neutral' },
  'S': { name: 'Serine', type: 'Hydroxyl-containing', polarity: 'Polar', charge: 'Neutral' },
  'T': { name: 'Threonine', type: 'Hydroxyl-containing', polarity: 'Polar', charge: 'Neutral' },
  'W': { name: 'Tryptophan', type: 'Aromatic', polarity: 'Nonpolar', charge: 'Neutral' },
  'Y': { name: 'Tyrosine', type: 'Aromatic', polarity: 'Polar', charge: 'Neutral' },
  'V': { name: 'Valine', type: 'Aliphatic', polarity: 'Nonpolar', charge: 'Neutral' },
  '*': { name: 'Stop Codon', type: 'Termination', polarity: 'N/A', charge: 'N/A' },
  '-': { name: 'Gap', type: 'N/A', polarity: 'N/A', charge: 'N/A' },
  '?': { name: 'Unknown', type: 'N/A', polarity: 'N/A', charge: 'N/A' }
};

function AminoAcid({ 
  index, 
  char1,
  char2, 
  type, 
  total 
}: { 
  index: number; 
  char1?: string;
  char2?: string; 
  type: 'match' | 'mismatch' | 'insertion' | 'deletion' | 'frameshift';
  total: number;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const currentScale = useRef(1);
  
  // Create a random-ish path for the protein chain
  const x = Math.sin(index * 0.8) * 2;
  const y = (index - total / 2) * 1.2;
  const z = Math.cos(index * 0.8) * 2;

  useFrame((state, delta) => {
    if (meshRef.current) {
      const t = state.clock.getElapsedTime();
      meshRef.current.position.x = x + Math.sin(t + index) * 0.1;
      meshRef.current.position.z = z + Math.cos(t + index) * 0.1;

      // Interactive hover physics (spring-like scale)
      const targetScale = hovered ? 1.3 : 1;
      currentScale.current = THREE.MathUtils.lerp(currentScale.current, targetScale, delta * 10);
      meshRef.current.scale.setScalar(currentScale.current);
    }
  });

  const color = AMINO_ACID_COLORS[type];
  const displayChar = type === 'deletion' ? char1 : char2;
  const props = AMINO_ACID_PROPERTIES[displayChar || '?'] || AMINO_ACID_PROPERTIES['?'];

  return (
    <group 
      position={[x, y, z]}
      onPointerOver={(e) => { e.stopPropagation(); setHovered(true); document.body.style.cursor = 'pointer'; }}
      onPointerOut={(e) => { e.stopPropagation(); setHovered(false); document.body.style.cursor = 'auto'; }}
    >
      <mesh ref={meshRef}>
        <sphereGeometry args={[0.4, 32, 32]} />
        <meshPhysicalMaterial 
          color={color} 
          emissive={color} 
          emissiveIntensity={type !== 'match' ? 1 : 0.2}
          roughness={0.2}
          metalness={0.1}
          clearcoat={1}
          clearcoatRoughness={0.1}
          transmission={type === 'deletion' ? 0.9 : 0.5}
          ior={1.5}
          transparent={type === 'deletion'}
          opacity={type === 'deletion' ? 0.3 : 1}
        />
      </mesh>
      <Text
        position={[0, 0.6, 0]}
        fontSize={0.2}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {displayChar}
      </Text>
      
      {hovered && (
        <Html position={[0, 1, 0]} center zIndexRange={[100, 0]}>
          <div className="bg-slate-900/95 backdrop-blur-md border border-slate-700 p-3 rounded-lg shadow-2xl w-48 pointer-events-none">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h4 className="text-xs font-bold text-white">{props.name}</h4>
                <span className="text-[10px] font-mono text-slate-400">Residue {index + 1}</span>
              </div>
              <div className="w-6 h-6 rounded bg-slate-800 flex items-center justify-center text-xs font-bold text-white border border-slate-700">
                {displayChar}
              </div>
            </div>
            
            <div className="space-y-1 mb-2">
              <div className="flex justify-between text-[9px]">
                <span className="text-slate-500">Type</span>
                <span className="text-slate-300">{props.type}</span>
              </div>
              <div className="flex justify-between text-[9px]">
                <span className="text-slate-500">Polarity</span>
                <span className="text-slate-300">{props.polarity}</span>
              </div>
              <div className="flex justify-between text-[9px]">
                <span className="text-slate-500">Charge</span>
                <span className="text-slate-300">{props.charge}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800">
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
                <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color }}>
                  {type}
                </span>
              </div>
              {type === 'mismatch' && (
                <p className="text-[9px] text-slate-400 mt-1">
                  Mutated from <span className="font-bold text-white">{char1}</span> to <span className="font-bold text-white">{char2}</span>
                </p>
              )}
              {type === 'frameshift' && (
                <p className="text-[9px] text-slate-400 mt-1">
                  Shifted from <span className="font-bold text-white">{char1}</span> to <span className="font-bold text-white">{char2}</span>
                </p>
              )}
            </div>
          </div>
        </Html>
      )}
    </group>
  );
}

function ProteinChain({ diffs }: { diffs: any[] }) {
  const points = useMemo(() => {
    return diffs.map((_, i) => {
      const x = Math.sin(i * 0.8) * 2;
      const y = (i - diffs.length / 2) * 1.2;
      const z = Math.cos(i * 0.8) * 2;
      return new THREE.Vector3(x, y, z);
    });
  }, [diffs]);

  const curve = useMemo(() => {
    return new THREE.CatmullRomCurve3(points);
  }, [points]);

  return (
    <group>
      <mesh>
        <tubeGeometry args={[curve, diffs.length * 2, 0.1, 8, false]} />
        <meshPhysicalMaterial color="#475569" transparent opacity={0.5} roughness={0.1} metalness={0.8} clearcoat={1} />
      </mesh>
      {diffs.map((diff, i) => (
        <AminoAcid 
          key={i} 
          index={i} 
          char1={diff.char1}
          char2={diff.char2} 
          type={diff.type} 
          total={diffs.length} 
        />
      ))}
    </group>
  );
}

export function Protein3DViewer({ protein, diffs = [] }: Protein3DViewerProps) {
  const safeProtein = protein || '';
  // If no diffs provided, treat all as matches
  const fullDisplayDiffs = diffs.length > 0 ? diffs : safeProtein.split('').map(char => ({ char1: char, char2: char, type: 'match' as const }));

  // Limit rendering to prevent WebGL crashes on massive proteins
  const MAX_RENDER_AAS = 150;
  let renderStart = 0;
  let renderEnd = fullDisplayDiffs.length;

  if (fullDisplayDiffs.length > MAX_RENDER_AAS) {
    // Find first mutation to center around, or default to start
    const firstMutationIndex = fullDisplayDiffs.findIndex(d => d.type !== 'match');
    
    if (firstMutationIndex !== -1) {
      renderStart = Math.max(0, firstMutationIndex - Math.floor(MAX_RENDER_AAS / 2));
      renderEnd = Math.min(fullDisplayDiffs.length, renderStart + MAX_RENDER_AAS);
      if (renderEnd - renderStart < MAX_RENDER_AAS) {
         renderStart = Math.max(0, renderEnd - MAX_RENDER_AAS);
      }
    } else {
      renderEnd = Math.min(fullDisplayDiffs.length, MAX_RENDER_AAS);
    }
  }

  const displayDiffs = fullDisplayDiffs.slice(renderStart, renderEnd);

  return (
    <div className="w-full h-[450px] bg-slate-900 rounded-3xl overflow-hidden relative border border-slate-800 shadow-2xl group">
      {/* HUD Lines */}
      <div className="absolute inset-8 pointer-events-none z-10">
        <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-white/10" />
        <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-white/10" />
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-white/10" />
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-white/10" />
      </div>

      <Canvas shadows dpr={[1, 2]}>
        <fog attach="fog" args={['#0f172a', 15, 45]} />
        <Environment preset="studio" />
        <PerspectiveCamera makeDefault position={[10, 0, 10]} fov={40} />
        <OrbitControls enableDamping dampingFactor={0.05} autoRotate autoRotateSpeed={0.3} />
        
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1.5} />
        <spotLight position={[-15, 20, 10]} angle={0.2} penumbra={1} intensity={2} castShadow />
        
        <Stars radius={100} depth={50} count={2000} factor={4} saturation={0} fade speed={0.5} />
        <Sparkles count={150} scale={25} size={1.5} speed={0.3} opacity={0.2} color="#ffffff" />

        <Float speed={1.2} rotationIntensity={0.2} floatIntensity={0.2}>
          <ProteinChain diffs={displayDiffs} />
        </Float>
      </Canvas>

      <div className="absolute top-10 left-10 flex flex-col gap-1 z-20">
        <span className="text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">Morphic v2.0</span>
        <div className="flex items-center gap-3">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
          <span className="text-[10px] font-black text-white uppercase tracking-widest leading-none">Proteomic Fold Analysis</span>
        </div>
      </div>
      
      <div className="absolute bottom-10 right-10 z-20 flex flex-col items-end gap-2">
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 px-4 py-2 rounded-xl">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Residue Count: <span className="text-white">{safeProtein.length} AA</span></span>
        </div>
      </div>
    </div>
  );
}
