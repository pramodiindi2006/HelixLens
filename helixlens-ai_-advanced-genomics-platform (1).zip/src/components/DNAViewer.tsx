import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { VirtuosoGrid } from 'react-virtuoso';

interface DNAViewerProps {
  sequence: string;
  highlights?: { start: number; end: number; color: string; label?: string }[];
  onBaseClick?: (index: number) => void;
  cutPosition?: number | null;
}

const BASE_COLORS: Record<string, string> = {
  A: 'text-emerald-400 bg-emerald-400/10',
  T: 'text-rose-400 bg-rose-400/10',
  G: 'text-amber-400 bg-amber-400/10',
  C: 'text-sky-400 bg-sky-400/10',
  '-': 'text-red-500 bg-red-500/10 border-red-500/30',
};

export function DNAViewer({ sequence, highlights = [], onBaseClick, cutPosition }: DNAViewerProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const safeSequence = sequence || '';

  const getHighlight = (index: number) => {
    return highlights.find(h => index >= h.start && index < h.end);
  };

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden font-mono text-sm shadow-2xl relative">
      <div className="absolute inset-0 pointer-events-none z-10 border-[1px] border-white/5 opacity-30" />
      <div className="flex items-center justify-between px-8 py-4 bg-slate-800/30 border-b border-slate-800 backdrop-blur-md">
        <div className="flex flex-col">
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Sequence Stream</span>
          <span className="text-[9px] font-bold text-slate-600 uppercase tracking-[0.1em] mt-0.5">Nucleotide Resolution: 1.0Å</span>
        </div>
        <div className="flex gap-6 text-[9px] font-black uppercase tracking-widest">
          {Object.entries(BASE_COLORS).map(([base, colorClass]) => (
            <div key={base} className="flex items-center gap-2">
              <div className={cn("w-2 h-2 rounded-full", colorClass.split(' ')[1])} />
              <span className="text-slate-400">{base}</span>
            </div>
          ))}
        </div>
      </div>
      
      <VirtuosoGrid
        style={{ height: '350px', width: '100%' }}
        totalCount={safeSequence.length}
        listClassName="flex flex-wrap gap-y-4 gap-x-1.5 p-8"
        itemClassName="flex-none"
        itemContent={(i) => {
          const base = safeSequence[i];
          const highlight = getHighlight(i);
          const isCut = cutPosition !== null && i === cutPosition;
          
          return (
            <div
              className="relative group"
              onMouseEnter={() => setHoveredIndex(i)}
              onMouseLeave={() => setHoveredIndex(null)}
              onClick={() => onBaseClick?.(i)}
            >
              {isCut && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 flex flex-col items-center">
                  <div className="w-1 h-3 bg-red-500 animate-pulse rounded-full" />
                </div>
              )}
              
              <div
                className={cn(
                  "w-9 h-11 flex items-center justify-center rounded-xl transition-all duration-300 cursor-pointer border border-white/5",
                  BASE_COLORS[base] || 'text-slate-400 bg-slate-800',
                  highlight && `border-white/20 bg-white/10 scale-105 shadow-xl ring-2 ring-white/5`,
                  hoveredIndex === i && "bg-white text-black border-white scale-110 z-10",
                )}
              >
                <span className="text-lg font-black tracking-tighter">{base}</span>
              </div>
              
              {highlight && highlight.start === i && highlight.label && (
                <div className={cn("absolute -top-6 left-0 text-[8px] font-black uppercase tracking-tighter whitespace-nowrap bg-black/80 px-1.5 py-0.5 rounded border border-white/10", highlight.color.replace('border-', 'text-'))}>
                  {highlight.label}
                </div>
              )}
            </div>
          );
        }}
      />
      
      <div className="px-8 py-3 bg-slate-800/20 border-t border-slate-800 flex justify-between items-center text-[9px] font-bold text-slate-500 uppercase tracking-[0.2em]">
        <div className="flex items-center gap-6">
          <span>Payload Size: <span className="text-white">{safeSequence.length} BP</span></span>
          {hoveredIndex !== null && (
            <span>Cursor: <span className="text-white">{safeSequence[hoveredIndex]}</span> AT POSITION <span className="text-white">{hoveredIndex + 1}</span></span>
          )}
        </div>
      </div>
    </div>
  );
}
