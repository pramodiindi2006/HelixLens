import React from 'react';
import { motion } from 'motion/react';
import { Scenario, SCENARIOS } from '../types/bio';
import { 
  BookOpen, ChevronRight, CheckCircle2, 
  Target, Info, ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface ScenarioModeProps {
  onSelect: (scenario: Scenario) => void;
  activeScenarioId: string | null;
  currentStepIndex: number;
}

export const ScenarioMode: React.FC<ScenarioModeProps> = ({ onSelect, activeScenarioId, currentStepIndex }) => {
  return (
    <div className="space-y-6">
      {!activeScenarioId ? (
        <div className="grid grid-cols-1 gap-4">
          {SCENARIOS.map((scenario) => (
            <div 
              key={scenario.id} 
              className="bg-slate-800/50 border border-white/10 hover:border-white/20 transition-all cursor-pointer group p-6 rounded-3xl relative overflow-hidden shadow-lg"
              onClick={() => onSelect(scenario)}
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="flex gap-6 items-center">
                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-white text-white group-hover:text-black transition-all">
                  <BookOpen className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-sm font-black text-white uppercase tracking-widest">{scenario.title}</h3>
                    <div className="px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-[8px] font-black uppercase text-slate-500 tracking-tighter">Case Study</div>
                  </div>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed">{scenario.description}</p>
                </div>
                <div className="w-10 h-10 rounded-full border border-white/5 flex items-center justify-center group-hover:border-white/20 transition-colors">
                  <ChevronRight className="w-4 h-4 text-slate-700 group-hover:text-white transition-colors" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          <div className="p-6 bg-white/5 border border-white/10 rounded-3xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-3">
               <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-white text-black rounded-lg">
                <Target className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-black uppercase text-white tracking-[0.2em]">Research Objective</span>
            </div>
            <p className="text-sm font-black text-white leading-relaxed">
              {SCENARIOS.find(s => s.id === activeScenarioId)?.goal}
            </p>
          </div>

          <div className="space-y-3">
            {SCENARIOS.find(s => s.id === activeScenarioId)?.steps.map((step, index) => (
              <div 
                key={index}
                className={cn(
                  "flex items-center gap-4 p-5 rounded-2xl border transition-all relative overflow-hidden",
                  index === currentStepIndex ? "bg-white border-white shadow-2xl scale-[1.02] z-10" :
                  index < currentStepIndex ? "bg-white/5 border-white/10 opacity-60" :
                  "bg-slate-900/50 border-white/5 opacity-40"
                )}
              >
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-black shrink-0",
                  index === currentStepIndex ? "bg-black text-white" :
                  index < currentStepIndex ? "bg-emerald-500 text-white" :
                  "bg-slate-900 border border-white/10 text-slate-600"
                )}>
                  {index < currentStepIndex ? <CheckCircle2 className="w-4 h-4" /> : index + 1}
                </div>
                <span className={cn(
                  "text-xs font-bold uppercase tracking-tight",
                  index === currentStepIndex ? "text-black" : "text-slate-400"
                )}>{step}</span>
              </div>
            ))}
          </div>

          <button 
            className="w-full py-4 rounded-2xl border border-white/10 text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 hover:text-white hover:bg-white/5 transition-all"
            onClick={() => onSelect(null as any)}
          >
            Terminate Scenario
          </button>
        </div>
      )}
    </div>
  );
};
