import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { buttonVariants } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { BookText } from 'lucide-react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export function DocumentationDialog() {
  const [content, setContent] = useState('');

  useEffect(() => {
    fetch('/DOCUMENTATION.md')
      .then((r) => r.text())
      .then((text) => setContent(text))
      .catch((e) => console.error("Could not fetch documentation", e));
  }, []);

  return (
    <Dialog>
      <DialogTrigger className={buttonVariants({ variant: "ghost", size: "sm", className: "h-8 gap-2 text-slate-400 hover:text-slate-100 uppercase text-[10px] tracking-widest font-bold" })}>
        <BookText className="w-4 h-4" />
        Documentation
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[85vh] bg-slate-900 border-slate-700 text-slate-200">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
            Technical Documentation
          </DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[70vh] pr-4 mt-2">
          <div className="prose prose-invert prose-sm max-w-none prose-h1:text-2xl prose-h1:font-bold prose-h2:text-xl prose-h2:text-blue-300 prose-h2:mt-8 prose-h3:text-purple-300 prose-a:text-blue-400 prose-table:border-collapse prose-th:border prose-th:border-slate-700 prose-th:bg-slate-800 prose-td:border prose-td:border-slate-700">
            <Markdown remarkPlugins={[remarkGfm]}>{content}</Markdown>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
