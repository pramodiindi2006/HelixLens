import React, { useState } from 'react';
import { GeneData, SimulationResult, FamilyMember, GRNAGuide } from '../types/bio';
import { FileText, Download, Printer, ShieldAlert, FlaskConical, Dna, Sparkles, Loader2 } from 'lucide-react';
import { analyzeGeneticRisk } from '../lib/risk-engine';
import ReactMarkdown from 'react-markdown';

interface ScientificReportProps {
  gene: GeneData;
  simulation: SimulationResult | null;
  guide: GRNAGuide | null;
  familyMembers: FamilyMember[];
}

export const ScientificReport: React.FC<ScientificReportProps> = ({ gene, simulation, guide, familyMembers }) => {
  const riskAnalysis = analyzeGeneticRisk(gene, familyMembers);
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateAIReport = async () => {
    if (!simulation) return;
    setIsGenerating(true);
    try {
      const response = await fetch('/api/generate-scientific-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          diseaseName: gene.disease,
          geneSymbol: gene.name,
          dnaSequence: gene.sequence,
          editMode: simulation.mutationType,
          gRNA: guide?.sequence || 'N/A',
          pam: guide?.pam || 'N/A',
          efficiency: (simulation.prediction.cuttingEfficiency * 100).toFixed(1),
          successProb: (simulation.prediction.predictedKnockoutRate * 100).toFixed(1),
          hdrProb: (simulation.prediction.hdrProbability * 100).toFixed(1),
          nhejProb: (simulation.prediction.nhejProbability * 100).toFixed(1),
          frameshiftProb: (simulation.prediction.frameshiftProbability * 100).toFixed(1),
          inFrameProb: (simulation.prediction.inFrameProbability * 100).toFixed(1),
          indel: simulation.mutatedDNA && gene.sequence ? (simulation.mutatedDNA.length > gene.sequence.length ? `+${simulation.mutatedDNA.length - gene.sequence.length}bp` : `-${gene.sequence.length - simulation.mutatedDNA.length}bp`) : 'N/A',
          proteinOutput: "Translated polypeptide stream (modeled)",
          domains: gene.domains,
          inheritance: gene.inheritance,
          penetrance: gene.penetrance,
          pedigree: familyMembers
        })
      });
      const data = await response.json();
      if (data.report) {
        setAiReport(data.report);
      }
    } catch (e) {
      console.error("Report Generation Error:", e);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight italic">Student Case Study Report</h2>
          <p className="text-slate-400 text-sm mt-1">Academic Curriculum Documentation & Analysis</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={generateAIReport}
            disabled={isGenerating || !simulation}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600/10 border border-purple-500/30 rounded-xl hover:bg-purple-600/20 transition-all text-sm font-bold text-purple-400 disabled:opacity-50 disabled:cursor-not-allowed group"
          >
            {isGenerating ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4 group-hover:scale-110 transition-transform" />
            )}
            {aiReport ? 'Regenerate Analysis' : 'Generate Expert AI Report'}
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 transition-colors text-sm font-medium text-slate-300">
            <Printer className="w-4 h-4" /> Print
          </button>
        </div>
      </div>

      <div className="bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-serif p-10 shadow-2xl relative overflow-hidden">
        {isGenerating && (
          <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] z-20 flex flex-col items-center justify-center space-y-4">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-purple-100 border-t-purple-600 rounded-full animate-spin"></div>
              <FlaskConical className="w-6 h-6 text-purple-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
            </div>
            <div className="text-center">
              <p className="font-bold text-slate-900">HelixLens Education AI</p>
              <p className="text-sm text-slate-500">Synthesizing biological data for educational analysis...</p>
            </div>
          </div>
        )}

        {aiReport ? (
          <div className="prose prose-slate max-w-none prose-h1:text-center prose-h1:text-3xl prose-h1:font-bold prose-h1:border-b-2 prose-h1:border-slate-900 prose-h1:pb-6 prose-h1:mb-8 prose-h2:text-xl prose-h2:italic prose-h2:text-slate-600 prose-h3:text-2xl prose-h3:font-bold prose-h3:uppercase prose-h3:tracking-wider prose-h3:text-slate-800 prose-h3:mt-10 prose-h3:mb-4">
            <ReactMarkdown>{aiReport}</ReactMarkdown>
            
            <section className="mt-12 pt-8 border-t border-slate-300 text-[10px] text-slate-500 italic">
              <p>Certified HelixLens Digital Specimen Report ID: {Math.random().toString(36).substring(7).toUpperCase()}</p>
              <p>Computational Method: Deterministic Genome Repair Simulation Model v4.2.1</p>
            </section>
          </div>
        ) : (
          <>
            <header className="border-b-2 border-slate-900 pb-6 mb-8 text-center">
              <div className="flex justify-center mb-4 text-slate-800">
                <FlaskConical className="w-12 h-12" />
              </div>
              <h1 className="text-3xl font-bold mb-2 uppercase">In Silico CRISPR/Cas9 Editing Simulation</h1>
              <h2 className="text-xl italic text-slate-600 px-4">Locus: {gene.name} ({gene.name.toUpperCase()})</h2>
              <p className="mt-4 text-sm text-slate-500">Date: {new Date().toLocaleDateString()}</p>
            </header>

            <section className="mb-10">
              <h3 className="text-2xl font-bold mb-4 uppercase tracking-wider text-slate-800">1. Case Background & Context</h3>
              <p className="mb-4 leading-relaxed">
                This case study explores the biological foundations of a CRISPR-Cas9 mediated intervention targeting the <span className="font-bold">{gene.name}</span> gene. {gene.description} This gene follows an <span className="italic">{gene.inheritance}</span> inheritance pattern with a documented penetrance of {(gene.penetrance || 1) * 100}%.
              </p>
              <div className="bg-slate-100 p-4 border-l-4 border-slate-400">
                <h4 className="font-bold mb-2">Hereditary Context</h4>
                <p className="text-sm">Based on the provided family pedigree ({familyMembers.filter(m => m.affected).length} affected individuals out of {familyMembers.length}), the computed carrier probability for the proband is <span className="font-bold">{riskAnalysis.carrierProbability.toFixed(1)}%</span>. The overall computed risk of disease expression without intervention is estimated at <span className="font-bold">{riskAnalysis.overallRisk.toFixed(1)}%</span>.</p>
              </div>
            </section>

            {simulation ? (
              <section className="mb-10">
                <h3 className="text-2xl font-bold mb-4 uppercase tracking-wider text-slate-800">2. In Silico Results</h3>
                
                <h4 className="text-lg font-bold mb-2">2.1 Cleavage Parameters</h4>
                <p className="mb-4 text-sm font-mono bg-slate-100 p-3 rounded">
                  Edit Mode: {simulation.mutationType.toUpperCase()} <br />
                  Target gRNA: {guide?.sequence} <br />
                  PAM: {guide?.pam} <br />
                </p>

                <h4 className="text-lg font-bold mb-2">2.2 Probability Distribution</h4>
                <div className="overflow-x-auto mb-6">
                  <table className="w-full text-left border-collapse border border-slate-300">
                    <thead>
                      <tr className="bg-slate-200">
                        <th className="border border-slate-300 p-2">Metric</th>
                        <th className="border border-slate-300 p-2">Probability</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="border border-slate-300 p-2">Cleavage Efficiency</td>
                        <td className="border border-slate-300 p-2">{(simulation.prediction.cuttingEfficiency * 100).toFixed(1)}%</td>
                      </tr>
                      <tr>
                        <td className="border border-slate-300 p-2">NHEJ Repair Pathway</td>
                        <td className="border border-slate-300 p-2">{(simulation.prediction.nhejProbability * 100).toFixed(1)}%</td>
                      </tr>
                      <tr>
                        <td className="border border-slate-300 p-2">HDR Repair Pathway</td>
                        <td className="border border-slate-300 p-2">{(simulation.prediction.hdrProbability * 100).toFixed(1)}%</td>
                      </tr>
                      <tr className="font-bold bg-slate-50">
                        <td className="border border-slate-300 p-2">Predicted Functional Knockout</td>
                        <td className="border border-slate-300 p-2">{(simulation.prediction.predictedKnockoutRate * 100).toFixed(1)}%</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <h4 className="text-lg font-bold mb-2">2.3 AI Impact Simulation</h4>
                <p className="mb-4 text-sm italic py-2">
                  Automated analysis based on current sequence state:
                </p>
                <div className="bg-red-50 text-red-900 border border-red-200 p-4 rounded-xl">
                  <p className="text-sm font-bold flex items-center gap-2 mb-1">
                    <ShieldAlert className="w-4 h-4" /> Structural Interpretation
                  </p>
                  <p className="text-xs leading-relaxed">{simulation.prediction.functionalImpact} {simulation.prediction.biologicalInterpretation}</p>
                </div>
              </section>
            ) : (
              <section className="mb-10">
                <h3 className="text-2xl font-bold mb-4 uppercase tracking-wider text-slate-800">2. In Silico Results</h3>
                <div className="bg-slate-100 border border-slate-300 border-dashed p-8 text-center text-slate-500 rounded-xl">
                  <Dna className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="font-medium text-slate-600">Pending Execution</p>
                  <p className="text-sm">Configure and run a CRISPR simulation in the lab to populate research data.</p>
                </div>
              </section>
            )}

            <section className="mb-10 text-sm text-slate-600 bg-slate-100 p-6 rounded-xl border border-slate-200">
               <h3 className="text-lg font-bold text-slate-800 mb-2 flex items-center gap-2"><ShieldAlert className="w-5 h-5 text-amber-600" /> Ethical Disclaimer</h3>
               <p className="mb-4">
                 The mathematical models presented herein provide a highly simplified representation of complex stochastic biological systems. The derived efficiencies do not guarantee in vivo/in vitro outcomes.
               </p>
               <p className="font-bold text-slate-900 border-t border-slate-300 pt-4">
                 This simulation is for learning and instructional purposes only and not for clinical or diagnostic use.
               </p>
            </section>
          </>
        )}
      </div>
    </div>
  );
};

