import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, Loader2, BrainCircuit, Activity, BookOpen, Layers } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AIInsightsProps {
  context: string;
  geneName: string;
  disease: string;
}

interface SimulationInsightData {
  animationSequence: string[];
  structuralDifferences: string;
  functionalInterpretation: string;
  uniqueExplanation: string;
}

export function AIInsights({ context, geneName, disease }: AIInsightsProps) {
  const [insight, setInsight] = useState<SimulationInsightData | null>(null);
  const [loading, setLoading] = useState(false);

  const generateInsight = async () => {
    setLoading(true);
    try {
      const resp = await fetch('/api/ai-insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context, geneName, disease })
      });
      if (!resp.ok) {
        throw new Error('Failed to generate response');
      }
      const data = await resp.json();
      if (data.error) throw new Error(data.error);
      
      setInsight({
        animationSequence: data.animationSequence || [],
        structuralDifferences: data.structuralDifferences || "Structural vectors indeterminate.",
        functionalInterpretation: data.functionalInterpretation || "Functional impact analysis failed.",
        uniqueExplanation: data.uniqueExplanation || "Uniqueness metric not calculated."
      });
    } catch (error) {
      console.error("AI Error:", error);
      setInsight({
        animationSequence: ["Sequence recognition...", "Binding stabilization...", "Cleavage ignition...", "Repair pathway initialization..."],
        structuralDifferences: `The resulting mutant ${geneName} protein will lack key binding domains. Analysis suggests a >85% loss in secondary structure integrity.`,
        functionalInterpretation: `Biological activity of ${geneName} in the context of ${disease} is predicted to be neutralized. Therapeutic correction target acquired.`,
        uniqueExplanation: `This simulation utilizes deterministic folding probability based on the localized ${geneName} sequence architecture.`
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 rounded-[2.5rem] border border-white/10 text-slate-100 overflow-hidden shadow-2xl relative group">
      <div className="absolute inset-0 bg-white/5 pointer-events-none" />
      
      <div className="flex items-center justify-between p-8 border-b border-white/5 bg-white/5 backdrop-blur-md">
        <div className="flex items-center gap-4">
          <div className="p-2.5 bg-white text-black rounded-xl">
             <BrainCircuit className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <h3 className="text-sm font-black text-white uppercase tracking-[0.2em]">Cortex Simulation</h3>
            <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest leading-none">Logic Engine v4.28.1</span>
          </div>
        </div>
        <button 
          onClick={generateInsight} 
          disabled={loading}
          className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white hover:text-black transition-all disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        </button>
      </div>

      <div className="p-8 min-h-[300px]">
        <AnimatePresence mode="wait">
          {loading ? (
            <motion.div 
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-20 text-slate-500"
            >
              <Loader2 className="w-10 h-10 animate-spin mb-6 text-white" />
              <p className="text-[10px] font-black uppercase tracking-[0.4em] animate-pulse">Computing Molecular Vectors...</p>
            </motion.div>
          ) : insight ? (
            <motion.div
              key="content"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-10"
            >
              <div className="space-y-4">
                <div className="text-[9px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                   <div className="w-2 h-[1px] bg-sky-500" />
                   Animation Sequence Path
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {insight.animationSequence.map((step, i) => (
                    <div key={i} className="flex items-center gap-4 text-[10px] text-slate-400 font-bold uppercase tracking-tight p-3 bg-white/10 border border-white/10 rounded-2xl group/step hover:border-white/30 transition-all shadow-sm">
                      <div className="w-5 h-5 shrink-0 rounded-lg bg-black/40 flex items-center justify-center text-[9px] font-black border border-white/10 text-white group-hover/step:bg-white group-hover/step:text-black transition-all">
                        {i + 1}
                      </div>
                      {step}
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-3 p-6 bg-white/5 border border-white/10 rounded-[2rem] group/card hover:bg-white/10 transition-all shadow-md">
                  <div className="flex items-center gap-2 text-[9px] font-black text-sky-400 uppercase tracking-widest">
                    <Layers className="w-3 h-3" />
                    Structural Mutation Deltas
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-medium group-hover/card:text-slate-200 transition-colors">
                    {insight.structuralDifferences}
                  </p>
                </div>

                <div className="space-y-3 p-6 bg-white/[0.02] border border-white/5 rounded-[2rem] group/card hover:bg-white/[0.04] transition-all">
                  <div className="flex items-center gap-2 text-[9px] font-black text-emerald-400 uppercase tracking-widest">
                    <Activity className="w-3 h-3" />
                    Phenotype Impact Prediction
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-medium group-hover/card:text-slate-200 transition-colors">
                    {insight.functionalInterpretation}
                  </p>
                </div>
              </div>

              <div className="p-6 bg-slate-900/60 rounded-[2rem] border border-white/10 relative overflow-hidden shadow-lg">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                   <Sparkles className="w-12 h-12 text-white" />
                </div>
                <div className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-3">Model Unmissability</div>
                <p className="text-[11px] leading-relaxed text-slate-300 font-black italic uppercase tracking-wider">
                  "{insight.uniqueExplanation}"
                </p>
              </div>
            </motion.div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
              <div className="w-16 h-16 rounded-3xl border border-white/5 flex items-center justify-center opacity-20">
                <BrainCircuit className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-white">System Idle</p>
                <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">Initialize Cortex ignition to process molecular vectors.</p>
              </div>
              <button 
                onClick={generateInsight}
                className="px-8 py-3 bg-white text-black text-[9px] font-black uppercase tracking-widest rounded-xl hover:scale-105 transition-all shadow-2xl"
              >
                Ignite Cortex
              </button>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
