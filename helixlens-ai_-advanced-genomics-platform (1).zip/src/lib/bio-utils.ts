import { CODON_TABLE, GRNAGuide, OffTargetSite, SimulationResult, StoryStep, EditOperation } from '../types/bio';

/**
 * Finds all PAM sites (NGG) in a DNA sequence.
 */
export function findPAMSites(sequence: string): number[] {
  const pams: number[] = [];
  const regex = /.[G][G]/g; // Simplified NGG
  let match;
  while ((match = regex.exec(sequence)) !== null) {
    pams.push(match.index);
  }
  return pams;
}

/**
 * Designs gRNAs based on PAM sites.
 */
export function designGRNAs(sequence: string): GRNAGuide[] {
  const pamIndices = findPAMSites(sequence);
  const guides: GRNAGuide[] = [];

  pamIndices.forEach((index, i) => {
    if (index >= 20) {
      const gRNA = sequence.substring(index - 20, index);
      const pam = sequence.substring(index, index + 3);
      
      // Calculate GC content
      const gcCount = (gRNA.match(/[GC]/g) || []).length;
      const gcContent = gcCount / 20;

      // Deterministic calculation of off-target risk
      let hash = 0;
      for (let j = 0; j < gRNA.length; j++) {
        hash = (hash << 5) - hash + gRNA.charCodeAt(j);
        hash = hash & hash; // Convert to 32bit integer
      }
      const mismatchPotential = Math.abs(hash) % 500 / 1000; // Value between 0.0 and 0.5
      
      // Calculate a pseudo-Doench 2014 rule based efficiency score based on nucleotide distribution 
      // Favorable: G at -1 (pos 19), G at -2 (pos 18). Unfavorable: T at -4 (pos 16), C at +1.
      let efficiencyScore = 0.5; 
      
      // Purines at PAM proximal are good
      if (gRNA[19] === 'G') efficiencyScore += 0.15;
      if (gRNA[18] === 'G') efficiencyScore += 0.10;
      if (gRNA[19] === 'A') efficiencyScore += 0.05;
      
      // Pyrimidines at PAM proximal are bad
      if (gRNA[19] === 'T' || gRNA[19] === 'C') efficiencyScore -= 0.10;
      
      // Heavy T content is bad (can cause early transcription termination in U6 promoters)
      const tCount = (gRNA.match(/T/g) || []).length;
      if (tCount > 4) efficiencyScore -= (tCount - 4) * 0.05;
      
      // GC content Goldilocks zone (40-60%)
      if (gcContent >= 0.4 && gcContent <= 0.6) {
        efficiencyScore += 0.10;
      } else {
        efficiencyScore -= Math.abs(gcContent - 0.5) * 0.2;
      }

      // Mock CFD score & Chromatin Accessibility for "Research Level" feel
      const cfdScore = efficiencyScore * 0.95;
      const chromatinAccessibility = 0.5 + (Math.random() * 0.4); // Simulated open chromatin
      
      // Clamp between 0.1 and 0.99
      efficiencyScore = Math.max(0.1, Math.min(0.99, efficiencyScore * chromatinAccessibility));

      guides.push({
        sequence: gRNA,
        pam,
        start: index - 20,
        end: index,
        gcContent,
        mismatchPotential,
        efficiencyScore,
        cfdScore,
        chromatinAccessibility,
        rank: 0 // Will rank later
      });
    }
  });

  // Rank guides: Sort primarily by our derived Doench efficiency score. Higher is better.
  return guides
    .sort((a, b) => {
      // Sort descending by efficiency
      return b.efficiencyScore - a.efficiencyScore;
    })
    .map((g, i) => ({ ...g, rank: i + 1 }));
}

/**
 * Translates DNA to Protein via RNA intermediate.
 */
export function translateDNA(dna: string): string {
  // DNA -> RNA
  const rna = dna.toUpperCase().replace(/T/g, 'U');
  let protein = '';
  for (let i = 0; i < rna.length - 2; i += 3) {
    const codon = rna.substring(i, i + 3);
    const aa = CODON_TABLE[codon.replace(/U/g, 'T')] || '?';
    if (aa === '_') {
      protein += '*'; // Use * to represent stop codon in the UI
      break; // Stop translation at the first stop codon
    }
    protein += aa;
  }
  return protein;
}

/**
 * Aligns two sequences using Needleman-Wunsch algorithm.
 */
export function alignSequences(seq1: string, seq2: string) {
  const matchReward = 1;
  const mismatchPenalty = -1;
  const gapPenalty = -1;

  const m = seq1.length;
  const n = seq2.length;
  const score = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) score[i][0] = i * gapPenalty;
  for (let j = 0; j <= n; j++) score[0][j] = j * gapPenalty;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const match = score[i - 1][j - 1] + (seq1[i - 1] === seq2[j - 1] ? matchReward : mismatchPenalty);
      const delete1 = score[i - 1][j] + gapPenalty;
      const insert2 = score[i][j - 1] + gapPenalty;
      score[i][j] = Math.max(match, delete1, insert2);
    }
  }

  let align1 = '';
  let align2 = '';
  let i = m;
  let j = n;

  while (i > 0 && j > 0) {
    const currentScore = score[i][j];
    const match = score[i - 1][j - 1] + (seq1[i - 1] === seq2[j - 1] ? matchReward : mismatchPenalty);
    
    if (currentScore === match) {
      align1 = seq1[i - 1] + align1;
      align2 = seq2[j - 1] + align2;
      i--;
      j--;
    } else if (currentScore === score[i - 1][j] + gapPenalty) {
      align1 = seq1[i - 1] + align1;
      align2 = '-' + align2;
      i--;
    } else {
      align1 = '-' + align1;
      align2 = seq2[j - 1] + align2;
      j--;
    }
  }

  while (i > 0) {
    align1 = seq1[i - 1] + align1;
    align2 = '-' + align2;
    i--;
  }
  while (j > 0) {
    align1 = '-' + align1;
    align2 = seq2[j - 1] + align2;
    j--;
  }

  return { align1, align2 };
}

/**
 * Compares two protein sequences and returns diff data.
 */
export function compareProteins(original: string, mutated: string, isFrameshift: boolean = false) {
  if (isFrameshift) {
    const diffs: { char1: string; char2: string; type: 'match' | 'mismatch' | 'insertion' | 'deletion' | 'frameshift' }[] = [];
    let divergencePoint = 0;
    
    while (divergencePoint < original.length && divergencePoint < mutated.length && original[divergencePoint] === mutated[divergencePoint]) {
      diffs.push({ char1: original[divergencePoint], char2: mutated[divergencePoint], type: 'match' });
      divergencePoint++;
    }
    
    for (let i = divergencePoint; i < Math.max(original.length, mutated.length); i++) {
      const c1 = original[i] || '-';
      const c2 = mutated[i] || '-';
      
      if (i < mutated.length) {
        diffs.push({ char1: c1, char2: c2, type: 'frameshift' });
      } else {
        diffs.push({ char1: c1, char2: c2, type: 'deletion' });
      }
    }
    return diffs;
  }

  const { align1, align2 } = alignSequences(original, mutated);
  
  const diffs: { char1: string; char2: string; type: 'match' | 'mismatch' | 'insertion' | 'deletion' | 'frameshift' }[] = [];
  
  for (let i = 0; i < align1.length; i++) {
    const c1 = align1[i];
    const c2 = align2[i];
    
    if (c1 === c2) {
      diffs.push({ char1: c1, char2: c2, type: 'match' });
    } else if (c1 === '-') {
      diffs.push({ char1: c1, char2: c2, type: 'insertion' });
    } else if (c2 === '-') {
      diffs.push({ char1: c1, char2: c2, type: 'deletion' });
    } else {
      diffs.push({ char1: c1, char2: c2, type: 'mismatch' });
    }
  }
  return diffs;
}

/**
 * Simulates a CRISPR edit. Supports multiple operations.
 */
export function simulateEdit(
  originalDNA: string,
  guide: GRNAGuide,
  mutationType: 'knockout' | 'knockin' | 'correction',
  editParams: { deletionSize?: number; insertionSeq?: string; substitutionBase?: string; substitutionPos?: number },
  additionalEdits: EditOperation[] = [],
  geneId?: string
): SimulationResult {
  const cutSite = guide.end - 3; // Cas9 cuts ~3bp upstream of PAM
  let mutatedDNA = originalDNA;

  // Primary edit
  const primaryEdit: EditOperation = {
    type: mutationType,
    position: cutSite,
    deletionSize: editParams.deletionSize,
    insertionSeq: editParams.insertionSeq,
    substitutionBase: editParams.substitutionBase
  };

  const allEdits = [primaryEdit, ...additionalEdits];
  
  // Apply edits in reverse order of position to avoid index shifting issues
  const sortedEdits = [...allEdits].sort((a, b) => b.position - a.position);

  sortedEdits.forEach(edit => {
    if (edit.type === 'knockout') {
      const size = edit.deletionSize || 1;
      mutatedDNA = mutatedDNA.substring(0, edit.position) + mutatedDNA.substring(edit.position + size);
    } else if (edit.type === 'knockin') {
      const seq = edit.insertionSeq || 'GATTACA';
      mutatedDNA = mutatedDNA.substring(0, edit.position) + seq + mutatedDNA.substring(edit.position);
    } else if (edit.type === 'correction') {
      const pos = edit.position;
      const base = edit.substitutionBase || 'A';
      mutatedDNA = mutatedDNA.substring(0, pos) + base + mutatedDNA.substring(pos + 1);
    }
  });

  const prediction = predictOutcome(mutationType, guide, allEdits, geneId);

  return {
    originalDNA,
    mutatedDNA,
    originalProtein: translateDNA(originalDNA),
    mutatedProtein: translateDNA(mutatedDNA),
    cutPosition: cutSite,
    mutationType,
    impact: mutatedDNA.length !== originalDNA.length ? 'Frameshift Mutation' : 'Point Mutation/In-frame',
    edits: allEdits,
    prediction
  };
}

/**
 * Predicts the outcome of an edit using a tiered biological evaluation model.
 */
export function predictOutcome(type: string, guide: GRNAGuide, edits: EditOperation[], geneId?: string) {
  const cutSite = guide.end - 3;
  const disruptionFactor = 0.9;
  
  // STEP 1: VALIDATE & CALCULATE CUTTING EFFICIENCY
  const gcPct = guide.gcContent * 100;
  const offTargetRisk = guide.mismatchPotential;
  
  let efficiency = 0;
  if (guide.pam.includes('GG')) {
    efficiency = 0.7 - 0.4 * (Math.abs(gcPct - 50) / 50) - 0.2 * offTargetRisk;
  }
  efficiency = Math.max(0, Math.min(1, efficiency));
  
  // STEP 2: REPAIR PATHWAY CONSTANTS (Depend on cell cycle, but typically NHEJ dominates)
  const pNHEJ = 0.95;
  const pHDR = 0.05;
  
  // STEP 3: MUTATION-LEVEL OUTCOMES (Sum to Efficiency)
  // Frameshift probability ≈ 2/3 of all indels
  const frameshiftProbWithinNHEJ = 0.66;
  const inFrameProbWithinNHEJ = 0.34;

  const nhejFrameshift = efficiency * pNHEJ * frameshiftProbWithinNHEJ;
  const nhejInframe = efficiency * pNHEJ * inFrameProbWithinNHEJ;
  const hdrOutcome = efficiency * pHDR;
  const unmodified = 1 - efficiency;

  // STEP 4: FUNCTIONAL OUTCOMES
  const functionalKO = nhejFrameshift * disruptionFactor;
  const partialFunction = nhejInframe;
  const noChange = unmodified;

  // STEP 5: MODE-SPECIFIC SUCCESS PROBABILITY
  let successRate = 0;
  if (type === 'knockout') {
    successRate = functionalKO;
  } else if (type === 'knockin') {
    successRate = hdrOutcome;
  } else if (type === 'correction') {
    successRate = hdrOutcome * 0.9; // correction efficiency
  }

  // STEP 6: BIOLOGICAL INTERPRETATION
  let functionalImpact = "General genetic modification.";
  if (geneId === 'cftr') {
    const relativePos = cutSite / 4500;
    if (relativePos < 0.25) functionalImpact = "Cut in TMD1: Likely disrupts channel protein insertion.";
    else if (relativePos < 0.50) functionalImpact = "Cut in NBD1: Likely prevents ATP binding and gating.";
    else if (relativePos < 0.75) functionalImpact = "Cut in TMD2: Likely destabilizes mature channel structure.";
    else functionalImpact = "Cut in NBD2: Likely impairs channel regulation and recycling.";
  } else if (geneId === 'hbb') {
    functionalImpact = "Any frameshift in HBB results in severe functional loss of hemoglobin beta.";
  } else if (geneId === 'htt') {
    if (cutSite < 500) functionalImpact = "Cut near polyQ region: High risk of aggregation disruption.";
    else functionalImpact = "Modification of huntingtin C-terminus: Uncertain functional impact.";
  }

  const mutationOutcomes = [
    { type: 'NHEJ (Frameshift)', probability: nhejFrameshift },
    { type: 'NHEJ (In-frame)', probability: nhejInframe },
    { type: 'HDR (Targeted Edit)', probability: hdrOutcome },
    { type: 'Unmodified (WT)', probability: unmodified }
  ];

  const functionalOutcomes = [
    { type: 'Functional KO', probability: functionalKO },
    { type: 'Partial Function', probability: partialFunction },
    { type: 'No Change', probability: noChange }
  ];

  return {
    successRate,
    successProbability: successRate, // Defined by mode-specific success logic
    cuttingEfficiency: efficiency,
    hdrProbability: hdrOutcome,
    nhejProbability: nhejFrameshift + nhejInframe,
    frameshiftProbability: frameshiftProbWithinNHEJ,
    inFrameProbability: inFrameProbWithinNHEJ,
    predictedKnockoutRate: functionalKO,
    mostLikelyIndel: "+1 bp",
    biologicalInterpretation: `Engine Output: ${type.toUpperCase()} mode active. Functional success strictly depends on downstream repair efficiency and protein disruption.`,
    functionalImpact,
    dominantOutcome: nhejFrameshift > nhejInframe ? 'NHEJ (Frameshift)' : 'NHEJ (In-frame)',
    riskLevel: (offTargetRisk > 0.3 ? 'High' : offTargetRisk > 0.15 ? 'Medium' : 'Low') as 'Low' | 'Medium' | 'High',
    mutationOutcomes,
    functionalOutcomes,
    outcomes: mutationOutcomes.sort((a, b) => b.probability - a.probability),
    pathogenicityScale: type === 'knockout' ? 0.95 : 0.05, // KO has high pathogenicity relative to WT
    populationFrequency: geneId ? `0.000${Math.floor(Math.random() * 9) + 1}% (estimated)` : "N/A"
  };
}

/**
 * Generates story steps for the CRISPR process.
 */
export function generateStorySteps(type: string): StoryStep[] {
  return [
    {
      title: 'Cas9 Complex Formation',
      description: 'The Cas9 protein binds with the guide RNA (gRNA) to form a ribonucleoprotein complex.',
      icon: 'Dna'
    },
    {
      title: 'Target Search',
      description: 'The complex scans the DNA for a matching sequence adjacent to a PAM site.',
      icon: 'Search'
    },
    {
      title: 'DNA Cleavage',
      description: 'Cas9 induces a double-strand break (DSB) at the target location.',
      icon: 'Zap'
    },
    {
      title: 'Cellular Repair',
      description: type === 'knockout' 
        ? 'The cell uses Non-Homologous End Joining (NHEJ), often resulting in small indels.'
        : 'The cell uses Homology-Directed Repair (HDR) with a template to introduce precise changes.',
      icon: 'Activity'
    }
  ];
}

/**
 * Simple off-target analysis.
 */
export function analyzeOffTargets(gRNA: string, genome: string): OffTargetSite[] {
  const sites: OffTargetSite[] = [];
  // In a real app, we'd scan the whole genome. Here we scan the current sequence.
  for (let i = 0; i <= genome.length - 20; i++) {
    const candidate = genome.substring(i, i + 20);
    let mismatches = 0;
    for (let j = 0; j < 20; j++) {
      if (candidate[j] !== gRNA[j]) mismatches++;
    }

    if (mismatches > 0 && mismatches <= 4) {
      sites.push({
        sequence: candidate,
        position: i,
        mismatches,
        risk: mismatches <= 2 ? 'High' : mismatches === 3 ? 'Medium' : 'Low'
      });
    }
  }
  return sites;
}
