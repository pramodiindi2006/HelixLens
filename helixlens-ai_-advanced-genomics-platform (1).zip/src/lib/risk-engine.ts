import { FamilyMember, GeneData, GeneticRiskAnalysis, InheritancePattern } from '../types/bio';

/**
 * Calculates genetic risk based on family history, inheritance patterns, and penetrance.
 */
export function analyzeGeneticRisk(gene: GeneData, family: FamilyMember[]): GeneticRiskAnalysis {
  const self = family.find(m => m.relation === 'Self');
  const parents = family.filter(m => m.relation.includes('Parent') || m.relation === 'Father' || m.relation === 'Mother');
  
  const affectedCount = family.filter(m => m.affected).length;
  const carrierCount = family.filter(m => m.carrier).length;

  let riskScore = 0;
  let carrierProb = 0;
  const findings: { title: string; description: string; impact: 'Low' | 'Medium' | 'High' }[] = [];
  const recommendations: string[] = [];

  // Mendelian Bayesian Logic Implementation
  switch (gene.inheritance) {
    case 'Autosomal Dominant':
      const affectedParent = parents.find(p => p.affected);
      if (affectedParent) {
        carrierProb = 0.5; // Actually heterozygous for AD
        riskScore = 50;
        findings.push({
          title: 'Direct AD Transmission',
          description: '50% Mendelian recurrence risk from affected parent.',
          impact: 'High'
        });
      } else if (affectedCount > 0) {
        carrierProb = 0.1; // De novo or mosaicism possibility
        riskScore = 10;
        findings.push({
          title: 'Non-Parental Load',
          description: 'Disease presence in distant relatives suggests variable expressivity.',
          impact: 'Medium'
        });
      }
      break;

    case 'Autosomal Recessive':
      const carriers = parents.filter(p => p.carrier || p.affected);
      if (carriers.length === 2) {
        // High risk of being affected (25%) or carrier (50%)
        carrierProb = 0.66; // If self is not yet affected, prob of being carrier is 2/3
        riskScore = 25;
        findings.push({
          title: 'Consanguinity/Dual Carrier Risk',
          description: 'Both parents are carriers. 25% pathogenic recurrence risk.',
          impact: 'High'
        });
      } else if (carriers.length === 1) {
        carrierProb = 0.5;
        riskScore = 5;
        findings.push({
          title: 'Single Carrier Parent',
          description: 'Low immediate risk, but 50% chance of obligate carrier status.',
          impact: 'Medium'
        });
      }
      break;

    case 'X-Linked Recessive':
      if (self?.sex === 'M') {
        const motherCarrier = family.find(m => m.relation === 'Mother' && (m.carrier || m.affected));
        if (motherCarrier) {
          carrierProb = 1.0; 
          riskScore = 50;
          findings.push({
            title: 'Hemi-zygous Risk',
            description: 'Male proband inherits affected X from carrier mother.',
            impact: 'High'
          });
        }
      } else {
        const fatherAffected = family.find(m => m.relation === 'Father' && m.affected);
        if (fatherAffected) {
          carrierProb = 1.0;
          findings.push({
            title: 'Obligate Female Carrier',
            description: 'All daughters of an affected father are obligate carriers.',
            impact: 'Medium'
          });
        }
      }
      break;
  }

  // Base prevalence and complexity
  if (gene.inheritance === 'Polygenic/Complex') {
    carrierProb = (affectedCount / family.length) * 1.5;
    riskScore = carrierProb * 100;
  }

  // Penetrance Adjustment
  const penetranceLoss = gene.penetrance ? (1 - gene.penetrance) * 100 : 0;
  if (penetranceLoss > 0) {
    riskScore = riskScore * (gene.penetrance || 1);
    findings.push({
      title: 'Reduced Penetrance',
      description: `Incomplete penetrance (${((gene.penetrance || 1) * 100).toFixed(0)}%) reduces the observed clinical risk.`,
      impact: 'Low'
    });
  }

  // Final scoring
  const overallRisk = Math.min(100, riskScore);
  const familyHistoryScore = (affectedCount * 10) + (carrierCount * 5);

  // Recommendations
  if (overallRisk > 50) {
    recommendations.push('Consider early diagnostic screening and specialist consultation.');
    recommendations.push('Full genetic sequencing (Exome/Genome) recommended to confirm status.');
  } else if (overallRisk > 10) {
    recommendations.push('Regular monitoring and lifestyle adjustments advised.');
    recommendations.push('Carrier screening suggested before family planning.');
  } else {
    recommendations.push('Continue standard preventive care.');
  }

  if (gene.id === 'pcsk9' || gene.id === 'brca1') {
    recommendations.push(`CRISPR-Cas9 precision editing (specifically ${gene.id === 'brca1' ? 'Correction' : 'Knockout'}) could be explored as a future therapeutic option.`);
  }

  return {
    overallRisk,
    carrierProbability: carrierProb * 100,
    penetranceEffect: (gene.penetrance || 1) * 100,
    familyHistoryScore,
    recommendations,
    findings
  };
}
