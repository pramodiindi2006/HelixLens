import React from 'react';
import { GenomicsPlatform } from './components/GenomicsPlatform';
import { Toaster } from 'sonner';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-900 font-sans selection:bg-purple-500/30">
      <Toaster position="top-right" theme="dark" />
      <GenomicsPlatform />
    </div>
  );
}
